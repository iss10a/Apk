package com.imou.audiocontroller

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import com.imou.audiocontroller.ui.MicButtonScreen

/**
 * تطبيق بشاشة واحدة فقط: زر 🎙️ لتشغيل صوت جاهز بتأخير وتكرار محددين، عبر
 * سماعة الهاتف نفسه. لا يوجد تسجيل دخول، ولا قائمة أجهزة، ولا أي اتصال
 * بالكاميرا -- أُزيلت كلها لأنها لم تعد مطلوبة لهذه الوظيفة (انظر التعليق
 * أعلى MicButtonScreen.kt لتفاصيل السبب التقني).
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface {
                    MicButtonScreen()
                }
            }
        }
    }
}
