package com.imou.audiocontroller

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.imou.audiocontroller.network.ImouOpenApiClient
import com.imou.audiocontroller.ui.DeviceListScreen
import com.imou.audiocontroller.ui.LiveViewScreen
import com.imou.audiocontroller.ui.LoginScreen
import com.imou.audiocontroller.ui.TalkScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface {
                    val navController = rememberNavController()
                    val apiClient = remember { mutableStateOf<ImouOpenApiClient?>(null) }
                    val selectedDeviceId = remember { mutableStateOf<String?>(null) }
                    val selectedChannelId = remember { mutableStateOf("0") }

                    NavHost(navController = navController, startDestination = "login") {
                        composable("login") {
                            LoginScreen(onLoggedIn = { client ->
                                apiClient.value = client
                                navController.navigate("devices")
                            })
                        }
                        composable("devices") {
                            DeviceListScreen(
                                apiClient = apiClient.value,
                                onDeviceSelected = { deviceId ->
                                    selectedDeviceId.value = deviceId
                                    navController.navigate("talk")
                                },
                                onLiveSelected = { deviceId, channelId ->
                                    selectedDeviceId.value = deviceId
                                    selectedChannelId.value = channelId
                                    navController.navigate("live")
                                }
                            )
                        }
                        composable("talk") {
                            TalkScreen(deviceId = selectedDeviceId.value)
                        }
                        composable("live") {
                            LiveViewScreen(
                                apiClient = apiClient.value,
                                deviceId = selectedDeviceId.value ?: "",
                                channelId = selectedChannelId.value
                            )
                        }
                    }
                }
            }
        }
    }
}
