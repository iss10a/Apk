package com.imou.audiocontroller.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * ============================================================================
 * ما تفعله هذه الخدمة فعليًا -- ولماذا هذه هي الطريقة الوحيدة الممكنة اليوم
 * ============================================================================
 * تُشغّل هذه الخدمة الملف الصوتي المختار كـ Foreground Service، بحيث يستمر
 * التشغيل حتى بعد الخروج من تطبيقنا وفتح IMOU Life الرسمي -- هذا الجزء حقيقي
 * ومضمون (خدمة أمامية قياسية في أندرويد، لا حيلة فيه).
 *
 * لكن **لا توجد على أندرويد أي طريقة مدعومة رسميًا لجعل صوت تطبيق (تطبيقنا)
 * "مصدر الميكروفون" الذي يقرأه تطبيق آخر (IMOU Life) عبر AudioRecord** --
 * سواء بإذن خاص أو API عام. هذا ليس قيدًا في IMOU SDK تحديدًا، بل في نظام
 * أندرويد نفسه: لا "كابل صوت افتراضي" مدمج، ولا API لتسجيل صوت تطبيق آخر
 * كميكروفون بديل، بدون صلاحيات root/تعديل نظام.
 *
 * الطريقة الوحيدة الحقيقية التي تعمل اليوم بدون root هي **فيزيائية/صوتية**:
 * تشغيل الملف بصوت عالٍ من سماعة الهاتف، ثم يلتقطه ميكروفون الهاتف الفعلي
 * عندما يضغط IMOU Life زر Talk (تمامًا كما لو كنت تتكلم بصوت عالٍ بجانب
 * الميكروفون). هذه الخدمة تجعل هذا التشغيل موثوقًا ومستمرًا في الخلفية،
 * وهذا أقصى ما يمكن فعله برمجيًا بدون تدخل مباشر من Imou نفسها.
 *
 * ⚠️ قيد تقني مهم يجب معرفته: أنظمة إلغاء صدى الصوت (Acoustic Echo
 * Cancellation / AEC) المدمجة في مسار الميكروفون على أغلب الهواتف مصممة
 * خصيصًا لإزالة أي صوت خارج من سماعة **نفس الجهاز** من إشارة الميكروفون
 * (لمنع سماع صدى نفسك في المكالمات). لو IMOU Life يستخدم مصدر ميكروفون من
 * نوع VOICE_COMMUNICATION (شائع لتطبيقات الاتصال الصوتي)، فمن المتوقع أن
 * يحاول النظام تلقائيًا إضعاف أو إلغاء الصوت القادم من سماعة **نفس الهاتف**
 * -- وهذا قد يجعل النتيجة ضعيفة أو شبه معدومة. **الحل العملي لتفادي هذا:
 * استخدم سماعة خارجية (بلوتوث أو سلكية) بدل سماعة الهاتف نفسه** وضعها قريبة
 * من ميكروفون الهاتف الذي يشغّل IMOU Life، أو استخدم هاتفًا ثانيًا للتشغيل
 * بجانب ميكروفون الهاتف الذي عليه IMOU Life -- في الحالتين لا يكون مصدر
 * الصوت ومسار الميكروفون على نفس الجهاز، فلا يُطبَّق عليه إلغاء الصدى.
 */
class AudioLoopService : Service() {

    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(Dispatchers.Main + serviceJob)
    private var loopJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopLoop("تم الإيقاف")
                return START_NOT_STICKY
            }
            ACTION_START -> {
                val uriString = intent.getStringExtra(EXTRA_URI) ?: return START_NOT_STICKY
                val delaySeconds = intent.getIntExtra(EXTRA_DELAY, 0)
                val continuous = intent.getBooleanExtra(EXTRA_CONTINUOUS, false)
                val totalRepeats = if (continuous) Int.MAX_VALUE else intent.getIntExtra(EXTRA_REPEATS, 1).coerceAtLeast(1)
                startLoop(Uri.parse(uriString), delaySeconds, totalRepeats, continuous)
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        loopJob?.cancel()
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun startLoop(uri: Uri, delaySeconds: Int, totalRepeats: Int, continuous: Boolean) {
        loopJob?.cancel()
        ensureChannel()
        startForeground(NOTIFICATION_ID, buildNotification("جارٍ التحضير..."))

        loopJob = serviceScope.launch {
            state.value = PlaybackState(running = true, currentRepeat = 0, totalRepeats = totalRepeats, continuous = continuous, status = "جارٍ التحضير...")
            try {
                var i = 1
                while (isActive && i <= totalRepeats) {
                    val label = if (continuous) "التكرار $i (مستمر)" else "التكرار $i / $totalRepeats"
                    if (delaySeconds > 0) {
                        for (s in delaySeconds downTo 1) {
                            if (!isActive) break
                            updateState(i, totalRepeats, continuous, "$label — بدء خلال $s...")
                            updateNotification("$label — بدء خلال $s...")
                            delay(1000)
                        }
                    }
                    if (!isActive) break
                    updateState(i, totalRepeats, continuous, "🔊 $label")
                    updateNotification("🔊 $label")
                    playFileOnce(uri)
                    i++
                }
                val finalMsg = if (continuous) "تم الإيقاف" else "✅ اكتمل: $totalRepeats/$totalRepeats"
                if (isActive) {
                    state.value = state.value.copy(running = false, status = finalMsg)
                }
            } catch (e: CancellationException) {
                // stopLoop() already set the status
            } catch (e: Exception) {
                state.value = state.value.copy(running = false, status = "خطأ: ${e.message}")
            } finally {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
    }

    private fun updateState(current: Int, total: Int, continuous: Boolean, status: String) {
        state.value = PlaybackState(running = true, currentRepeat = current, totalRepeats = total, continuous = continuous, status = status)
    }

    private suspend fun playFileOnce(uri: Uri) {
        suspendCancellableCoroutine<Unit> { cont ->
            val player = MediaPlayer()
            try {
                player.setDataSource(this@AudioLoopService, uri)
                player.setOnCompletionListener {
                    it.release()
                    if (cont.isActive) cont.resume(Unit)
                }
                player.setOnErrorListener { mp, _, _ ->
                    mp.release()
                    if (cont.isActive) cont.resume(Unit)
                    true
                }
                cont.invokeOnCancellation { runCatching { player.stop() }; runCatching { player.release() } }
                player.prepare()
                player.start()
            } catch (e: Exception) {
                runCatching { player.release() }
                if (cont.isActive) cont.resume(Unit)
            }
        }
    }

    private fun stopLoop(message: String) {
        loopJob?.cancel()
        loopJob = null
        state.value = state.value.copy(running = false, status = message)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mgr = getSystemService(NotificationManager::class.java)
            if (mgr.getNotificationChannel(CHANNEL_ID) == null) {
                mgr.createNotificationChannel(
                    NotificationChannel(CHANNEL_ID, "تدريب الببغاء", NotificationManager.IMPORTANCE_LOW)
                )
            }
        }
    }

    private fun buildNotification(text: String): Notification {
        val stopIntent = Intent(this, AudioLoopService::class.java).apply { action = ACTION_STOP }
        val stopPending = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("تدريب الببغاء")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "إيقاف", stopPending)
            .build()
    }

    private fun updateNotification(text: String) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val mgr = getSystemService(NotificationManager::class.java)
        mgr.notify(NOTIFICATION_ID, buildNotification(text))
    }

    data class PlaybackState(
        val running: Boolean = false,
        val currentRepeat: Int = 0,
        val totalRepeats: Int = 0,
        val continuous: Boolean = false,
        val status: String = "جاهز"
    )

    companion object {
        private const val CHANNEL_ID = "audio_loop_channel"
        private const val NOTIFICATION_ID = 42

        private const val ACTION_START = "com.imou.audiocontroller.action.START"
        private const val ACTION_STOP = "com.imou.audiocontroller.action.STOP"
        private const val EXTRA_URI = "extra_uri"
        private const val EXTRA_DELAY = "extra_delay"
        private const val EXTRA_REPEATS = "extra_repeats"
        private const val EXTRA_CONTINUOUS = "extra_continuous"

        private val state = MutableStateFlow(PlaybackState())
        val playbackState: StateFlow<PlaybackState> = state.asStateFlow()

        fun start(context: Context, uri: Uri, delaySeconds: Int, repeats: Int, continuous: Boolean) {
            val intent = Intent(context, AudioLoopService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_URI, uri.toString())
                putExtra(EXTRA_DELAY, delaySeconds)
                putExtra(EXTRA_REPEATS, repeats)
                putExtra(EXTRA_CONTINUOUS, continuous)
            }
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, AudioLoopService::class.java).apply { action = ACTION_STOP }
            context.startService(intent)
        }
    }
}
