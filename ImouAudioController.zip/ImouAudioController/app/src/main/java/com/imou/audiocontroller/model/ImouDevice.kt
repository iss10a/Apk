package com.imou.audiocontroller.model

/**
 * Minimal device model returned by the official Imou Open API
 * (deviceBaseDetailList / deviceBaseList methods).
 * Field names follow the documented response of open.imoulife.com.
 */
data class ImouDevice(
    val deviceId: String,
    val deviceName: String,
    val channelId: String = "0",
    val status: String = "UNKNOWN",
    /** Raw model string as returned by the API, e.g. "IPC-S41FE". Used only for display/matching. */
    val deviceModel: String? = null
) {
    val isTargetCamera: Boolean
        get() = deviceModel?.contains("S41FE", ignoreCase = true) == true
}
