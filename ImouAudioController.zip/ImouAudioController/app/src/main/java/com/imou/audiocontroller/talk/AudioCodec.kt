package com.imou.audiocontroller.talk

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.roundToInt

/**
 * The reference project (home-assistant-tools/imou-life) documents that
 * Imou/Dahua camera speakers have been observed accepting either:
 *   - PCMA (G.711 A-law) at 8000 Hz, or
 *   - AAC/ADTS at 16000 Hz
 * depending on camera model/firmware, and that the exact codec must stay
 * configurable per camera rather than hard-coded. This file only performs
 * the codec MATH (resampling + encoding), which is standard and verifiable
 * against public specs (ITU-T G.711, Android's built-in AAC encoder). It
 * does NOT implement the camera-facing transport/framing -- see
 * ImouTalkTransport.kt for what is and is not verified there.
 */
object AudioCodec {

    /** Very small linear resampler for mono 16-bit PCM. Adequate for voice/TTS-grade audio. */
    fun resampleMono16(pcm: ByteArray, fromRateHz: Int, toRateHz: Int): ByteArray {
        if (fromRateHz == toRateHz) return pcm
        val input = ShortArray(pcm.size / 2)
        ByteBuffer.wrap(pcm).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(input)

        val ratio = toRateHz.toDouble() / fromRateHz.toDouble()
        val outLen = (input.size * ratio).roundToInt()
        val output = ShortArray(outLen)
        for (i in 0 until outLen) {
            val srcPos = i / ratio
            val idx = srcPos.toInt().coerceIn(0, input.size - 1)
            val nextIdx = (idx + 1).coerceIn(0, input.size - 1)
            val frac = srcPos - idx
            output[i] = (input[idx] * (1 - frac) + input[nextIdx] * frac).roundToInt().toShort()
        }

        val outBytes = ByteArray(output.size * 2)
        ByteBuffer.wrap(outBytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(output)
        return outBytes
    }

    /** Downmixes interleaved 16-bit PCM with [channels] channels to mono by averaging. */
    fun toMono16(pcm: ByteArray, channels: Int): ByteArray {
        if (channels == 1) return pcm
        val input = ShortArray(pcm.size / 2)
        ByteBuffer.wrap(pcm).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(input)
        val frames = input.size / channels
        val out = ShortArray(frames)
        for (f in 0 until frames) {
            var sum = 0
            for (c in 0 until channels) sum += input[f * channels + c]
            out[f] = (sum / channels).toShort()
        }
        val outBytes = ByteArray(out.size * 2)
        ByteBuffer.wrap(outBytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(out)
        return outBytes
    }

    /** ITU-T G.711 A-law encoder (standard, documented algorithm -- not Imou-specific). */
    fun pcm16ToALaw(pcm: ByteArray): ByteArray {
        val samples = ShortArray(pcm.size / 2)
        ByteBuffer.wrap(pcm).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(samples)
        val out = ByteArray(samples.size)
        for (i in samples.indices) {
            out[i] = linearToALawSample(samples[i])
        }
        return out
    }

    private fun linearToALawSample(sampleIn: Short): Byte {
        val seg = intArrayOf(0x1F, 0x1F, 0x1F, 0x1F, 0x1F, 0x1F, 0x1F, 0x1F,
            0x1F, 0x1F, 0x1F, 0x1F, 0x1F, 0x1F, 0x1F, 0x1F,
            0x1F, 0x1F, 0x1F, 0x1F, 0x1F, 0x1F, 0x1F, 0x1F,
            0x1F, 0x1F, 0x1F, 0x1F, 0x1F, 0x1F, 0x1F, 0x1F)
        var pcm = sampleIn.toInt()
        val sign = if (pcm and 0x8000 != 0) 0x00 else 0x80
        if (sign == 0x00) pcm = (-pcm) and 0xFFFF
        if (pcm > 32635) pcm = 32635
        pcm += 0x84
        var exponent = segmentOf(pcm)
        val mantissa = (pcm shr (if (exponent == 0) 4 else exponent + 3)) and 0x0F
        var aByte = sign or (exponent shl 4) or mantissa
        aByte = aByte xor 0x55
        return aByte.toByte()
    }

    private fun segmentOf(pcmVal: Int): Int {
        var v = pcmVal shr 4
        for (exp in 7 downTo 0) {
            if ((v shr exp) and 0x01 != 0) return exp
        }
        return 0
    }

    /**
     * Encodes mono 16-bit PCM to AAC and wraps each access unit with an ADTS
     * header, using Android's built-in hardware/software AAC encoder
     * (MediaCodec, MIMETYPE_AUDIO_AAC). This mirrors the "AAC/ADTS" output
     * codec the reference project documents for P2P TTS delivery.
     */
    fun pcm16ToAacAdts(pcm: ByteArray, sampleRateHz: Int, bitRate: Int = 32000): ByteArray {
        val format = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sampleRateHz, 1).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, bitRate)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 8192)
        }
        val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec.start()

        val output = java.io.ByteArrayOutputStream()
        val bufferInfo = MediaCodec.BufferInfo()
        var offset = 0
        var inputDone = false
        var outputDone = false

        while (!outputDone) {
            if (!inputDone) {
                val inIndex = codec.dequeueInputBuffer(10_000)
                if (inIndex >= 0) {
                    val inBuf = codec.getInputBuffer(inIndex)!!
                    inBuf.clear()
                    val remaining = pcm.size - offset
                    if (remaining <= 0) {
                        codec.queueInputBuffer(inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        inputDone = true
                    } else {
                        val chunkSize = minOf(remaining, inBuf.capacity())
                        inBuf.put(pcm, offset, chunkSize)
                        codec.queueInputBuffer(inIndex, 0, chunkSize, 0, 0)
                        offset += chunkSize
                    }
                }
            }
            val outIndex = codec.dequeueOutputBuffer(bufferInfo, 10_000)
            if (outIndex >= 0) {
                val outBuf = codec.getOutputBuffer(outIndex)!!
                val raw = ByteArray(bufferInfo.size)
                outBuf.position(bufferInfo.offset)
                outBuf.get(raw)
                output.write(wrapAdts(raw, sampleRateHz, 1))
                codec.releaseOutputBuffer(outIndex, false)
                if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
            }
        }
        codec.stop()
        codec.release()
        return output.toByteArray()
    }

    /**
     * Writes mono 16-bit PCM as a standard 44-byte-header WAV/PCM file
     * (RIFF/WAVE, format tag 1). Generic file format, not Imou-specific --
     * used so the "test talk with mic" recording can be played back with
     * any standard player as real, listenable proof the mic path works,
     * instead of just showing a "done" label.
     */
    fun writeWavPcm16Mono(out: java.io.OutputStream, pcm: ByteArray, sampleRateHz: Int) {
        val byteRate = sampleRateHz * 2 // mono, 16-bit
        val dataLen = pcm.size
        val riffLen = 36 + dataLen
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        header.put("RIFF".toByteArray(Charsets.US_ASCII))
        header.putInt(riffLen)
        header.put("WAVE".toByteArray(Charsets.US_ASCII))
        header.put("fmt ".toByteArray(Charsets.US_ASCII))
        header.putInt(16) // PCM fmt chunk size
        header.putShort(1) // format = PCM
        header.putShort(1) // channels = mono
        header.putInt(sampleRateHz)
        header.putInt(byteRate)
        header.putShort(2) // block align (mono, 16-bit)
        header.putShort(16) // bits per sample
        header.put("data".toByteArray(Charsets.US_ASCII))
        header.putInt(dataLen)
        out.write(header.array())
        out.write(pcm)
    }

    private val ADTS_SAMPLE_RATES = intArrayOf(96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000, 7350)

    private fun wrapAdts(aacFrame: ByteArray, sampleRateHz: Int, channels: Int): ByteArray {
        val freqIdx = ADTS_SAMPLE_RATES.indexOf(sampleRateHz).let { if (it < 0) 8 else it } // default 16000
        val packetLen = aacFrame.size + 7
        val header = ByteArray(7)
        header[0] = 0xFF.toByte()
        header[1] = 0xF9.toByte() // MPEG-4, no CRC
        header[2] = ((2 shl 6) or (freqIdx shl 2) or (channels shr 2)).toByte() // AAC-LC profile
        header[3] = (((channels and 3) shl 6) or (packetLen shr 11)).toByte()
        header[4] = ((packetLen shr 3) and 0xFF).toByte()
        header[5] = (((packetLen and 7) shl 5) or 0x1F).toByte()
        header[6] = 0xFC.toByte()
        return header + aacFrame
    }
}
