package com.imou.audiocontroller.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.imou.audiocontroller.model.ImouDevice
import com.imou.audiocontroller.network.ImouOpenApiClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun DeviceListScreen(
    apiClient: ImouOpenApiClient?,
    onDeviceSelected: (String) -> Unit
) {
    var devices by remember { mutableStateOf<List<ImouDevice>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(true) }

    LaunchedEffect(apiClient) {
        if (apiClient == null) {
            error = "لم يتم تسجيل الدخول"
            loading = false
            return@LaunchedEffect
        }
        try {
            // Step 1: deviceBaseList only gives us deviceId + channels.
            val baseJson = withContext(Dispatchers.IO) { apiClient.listDevices() }
            val baseResult = baseJson.optJSONObject("result") ?: baseJson
            val baseData = baseResult.optJSONObject("data")
            val baseArr = baseData?.optJSONArray("deviceList")

            data class BaseInfo(val deviceId: String, val channelId: String)
            val baseList = mutableListOf<BaseInfo>()
            if (baseArr != null) {
                for (i in 0 until baseArr.length()) {
                    val d = baseArr.getJSONObject(i)
                    baseList.add(
                        BaseInfo(
                            deviceId = d.optString("deviceId"),
                            channelId = d.optJSONArray("channels")?.optJSONObject(0)?.optString("channelId") ?: "0"
                        )
                    )
                }
            }

            // Step 2: deviceBaseDetailList gives us name/status/model for those ids.
            val detailsById = mutableMapOf<String, org.json.JSONObject>()
            if (baseList.isNotEmpty()) {
                val detailJson = withContext(Dispatchers.IO) {
                    apiClient.listDeviceDetails(baseList.map { it.deviceId })
                }
                val detailResult = detailJson.optJSONObject("result") ?: detailJson
                val detailData = detailResult.optJSONObject("data")
                val detailArr = detailData?.optJSONArray("deviceList")
                if (detailArr != null) {
                    for (i in 0 until detailArr.length()) {
                        val d = detailArr.getJSONObject(i)
                        detailsById[d.optString("deviceId")] = d
                    }
                }
            }

            val list = baseList.map { base ->
                val d = detailsById[base.deviceId]
                ImouDevice(
                    deviceId = base.deviceId,
                    deviceName = d?.optString("name").takeUnless { it.isNullOrEmpty() } ?: base.deviceId,
                    channelId = base.channelId,
                    status = d?.optString("status", "UNKNOWN") ?: "UNKNOWN",
                    deviceModel = d?.optString("deviceModel")
                )
            }
            devices = list
        } catch (e: Exception) {
            error = "تعذر جلب الأجهزة: ${e.message}"
        } finally {
            loading = false
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("الأجهزة", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(12.dp))
        when {
            loading -> CircularProgressIndicator()
            error != null -> Text(error!!, color = MaterialTheme.colorScheme.error)
            devices.isEmpty() -> Text("لا توجد أجهزة مرتبطة بهذا الحساب.")
            else -> LazyColumn {
                items(devices) { device ->
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Text(device.deviceName, style = MaterialTheme.typography.titleMedium)
                            Text("Model: ${device.deviceModel ?: "?"}  •  ${device.status}")
                            if (device.isTargetCamera) {
                                Text("✅ IPC-S41FE-7E4F المستهدفة", color = MaterialTheme.colorScheme.primary)
                            }
                            Spacer(Modifier.height(8.dp))
                            Button(onClick = { onDeviceSelected(device.deviceId) }) {
                                Text("تدريب الببغاء")
                            }
                        }
                    }
                }
            }
        }
    }
}
