package com.imou.audiocontroller.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.imou.audiocontroller.model.ImouDevice
import com.imou.audiocontroller.network.ImouOpenApiClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun DeviceListScreen(apiClient: ImouOpenApiClient?, onDeviceSelected: (String) -> Unit) {
    var devices by remember { mutableStateOf<List<ImouDevice>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(true) }

    LaunchedEffect(apiClient) {
        if (apiClient == null) {
            error = "لم يتم تسجيل الدخول"
            loading = false
            return@LaunchedEffect
        }
        try {
            val json = withContext(Dispatchers.IO) { apiClient.listDevices() }
            val result = json.optJSONObject("result") ?: json
            val data = result.optJSONObject("data")
            val arr = data?.optJSONArray("deviceList")
            val list = mutableListOf<ImouDevice>()
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val d = arr.getJSONObject(i)
                    list.add(
                        ImouDevice(
                            deviceId = d.optString("deviceId"),
                            deviceName = d.optString("deviceName"),
                            channelId = d.optJSONArray("channels")?.optJSONObject(0)?.optString("channelId") ?: "0",
                            status = d.optString("status", "UNKNOWN"),
                            deviceModel = d.optString("deviceModel", null)
                        )
                    )
                }
            }
            devices = list
        } catch (e: Exception) {
            error = "تعذر جلب الأجهزة: ${e.message}"
        } finally {
            loading = false
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("الأجهزة", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(12.dp))
        when {
            loading -> CircularProgressIndicator()
            error != null -> Text(error!!, color = MaterialTheme.colorScheme.error)
            devices.isEmpty() -> Text("لا توجد أجهزة مرتبطة بهذا الحساب.")
            else -> LazyColumn {
                items(devices) { device ->
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Text(device.deviceName, style = MaterialTheme.typography.titleMedium)
                            Text("Model: ${device.deviceModel ?: "?"}  •  ${device.status}")
                            if (device.isTargetCamera) {
                                Text("✅ IPC-S41FE-7E4F المستهدفة", color = MaterialTheme.colorScheme.primary)
                            }
                            Spacer(Modifier.height(8.dp))
                            Button(onClick = { onDeviceSelected(device.deviceId) }) {
                                Text("فتح")
                            }
                        }
                    }
                }
            }
        }
    }
}
