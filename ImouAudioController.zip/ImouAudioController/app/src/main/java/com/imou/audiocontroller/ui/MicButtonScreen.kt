package com.imou.audiocontroller.ui

import android.media.MediaPlayer
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * ============================================================================
 * ما هذا الزر فعليًا -- ولماذا (اقرأ قبل التعديل)
 * ============================================================================
 * هذا الزر مصمم بشكل وسلوك يشبهان زر الميكروفون/التسجيل في التطبيق الرسمي،
 * لكنه لا يسجّل من ميكروفون الهاتف الحقيقي إطلاقًا. بدلًا من ذلك: عند
 * الضغط عليه، ينتظر المدة المحددة، ثم يشغّل ملفًا صوتيًا جاهزًا عبر
 * MediaPlayer القياسي، ويكرر ذلك بالعدد المطلوب (أو باستمرار).
 *
 * **الصوت يخرج من سماعة الهاتف نفسه (المسار العادي لتشغيل الوسائط في
 * أندرويد) -- وليس من سماعة الكاميرا، وليس عبر مسار ميكروفون أي مكتبة
 * كاميرا.** تم التأكيد على هذا صراحة مع المستخدم قبل البناء، للسبب التالي:
 *
 * لا توجد في هذا المشروع أي مكتبة اتصال بالكاميرا (LCOpenSDK.aar غير متوفر
 * ولم يكن مُدمجًا أصلًا)، وحتى لو كانت متوفرة فواجهتها الموثقة رسميًا
 * (playTalk/stopTalk) لا تملك أي نقطة ربط لحقن صوت جاهز بدل الميكروفون
 * الحقيقي. كما أن أندرويد نفسه لا يسمح لتطبيق عادي (بدون root) باستبدال
 * دخل الميكروفون الذي تقرأه مكتبة أخرى. لذلك هذا التطبيق لا يحاول ادّعاء
 * الاتصال بأي كاميرا -- هو فقط مشغّل صوت مجدول، بواجهة تشبه زر التسجيل.
 */
@Composable
fun MicButtonScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var pickedUri by remember { mutableStateOf<Uri?>(null) }
    var pickedFileName by remember { mutableStateOf<String?>(null) }
    var delayText by remember { mutableStateOf("5") }
    var repeatsText by remember { mutableStateOf("3") }
    var continuous by remember { mutableStateOf(false) }

    var running by remember { mutableStateOf(false) }
    var currentRepeat by remember { mutableStateOf(0) }
    var countdownSeconds by remember { mutableStateOf<Int?>(null) }
    var statusText by remember { mutableStateOf("جاهز") }
    var job by remember { mutableStateOf<Job?>(null) }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            pickedUri = it
            pickedFileName = it.lastPathSegment
        }
    }

    suspend fun playFile(uri: Uri) {
        suspendCancellableCoroutine<Unit> { cont ->
            val player = MediaPlayer()
            try {
                player.setDataSource(context, uri)
                player.setOnCompletionListener {
                    it.release()
                    if (cont.isActive) cont.resume(Unit)
                }
                player.setOnErrorListener { mp, _, _ ->
                    mp.release()
                    if (cont.isActive) cont.resume(Unit)
                    true
                }
                cont.invokeOnCancellation { runCatching { player.stop() }; runCatching { player.release() } }
                player.prepare()
                player.start()
            } catch (e: Exception) {
                runCatching { player.release() }
                if (cont.isActive) cont.resume(Unit)
            }
        }
    }

    fun stopAll(message: String = "تم الإيقاف") {
        job?.cancel()
        job = null
        running = false
        countdownSeconds = null
        statusText = message
    }

    fun startTraining() {
        val uri = pickedUri ?: return
        val delaySeconds = delayText.toIntOrNull() ?: 0
        val totalRepeats = if (continuous) Int.MAX_VALUE else (repeatsText.toIntOrNull()?.coerceAtLeast(1) ?: 1)

        running = true
        currentRepeat = 0
        job = scope.launch {
            try {
                var i = 1
                while (isActive && i <= totalRepeats) {
                    currentRepeat = i
                    statusText = if (continuous) "التكرار $i (مستمر)" else "التكرار $i / $totalRepeats"

                    if (delaySeconds > 0) {
                        for (s in delaySeconds downTo 1) {
                            if (!isActive) break
                            countdownSeconds = s
                            delay(1000)
                        }
                    }
                    countdownSeconds = null
                    if (!isActive) break

                    statusText = if (continuous) "🔊 يُشغّل الآن (تكرار $i)" else "🔊 يُشغّل الآن ($i / $totalRepeats)"
                    playFile(uri)
                    i++
                }
                if (isActive) {
                    statusText = if (continuous) "تم الإيقاف" else "✅ اكتمل: ${totalRepeats}/${totalRepeats}"
                }
            } catch (e: CancellationException) {
                statusText = "تم الإيقاف عند التكرار $currentRepeat"
            } finally {
                running = false
                countdownSeconds = null
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("تدريب الببغاء", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(
            "الصوت يُشغَّل من سماعة الهاتف نفسه — قرّب الهاتف من القفص",
            style = MaterialTheme.typography.bodySmall,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("الملف الصوتي", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        enabled = !running,
                        onClick = { filePicker.launch(arrayOf("audio/*")) }
                    ) { Text("إضافة صوت") }
                    Spacer(Modifier.width(10.dp))
                    Text(pickedFileName ?: "لا يوجد ملف بعد", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("الإعدادات", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = delayText,
                    onValueChange = { if (it.all(Char::isDigit)) delayText = it },
                    label = { Text("الانتظار قبل كل تشغيل (ثوانٍ)") },
                    enabled = !running,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = repeatsText,
                    onValueChange = { if (it.all(Char::isDigit)) repeatsText = it },
                    label = { Text("عدد التكرارات") },
                    enabled = !running && !continuous,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = continuous, onCheckedChange = { if (!running) continuous = it })
                    Text("تكرار مستمر (حتى الضغط إيقاف)")
                }
            }
        }

        Spacer(Modifier.height(28.dp))

        val buttonColor = if (running) Color(0xFFD32F2F) else MaterialTheme.colorScheme.primary
        Box(
            modifier = Modifier
                .size(110.dp)
                .clip(CircleShape)
                .background(buttonColor)
                .clickable(enabled = pickedUri != null) {
                    if (running) stopAll() else startTraining()
                },
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = if (running) "■" else "🎙️",
                fontSize = 40.sp,
                color = Color.White
            )
        }

        Spacer(Modifier.height(16.dp))
        countdownSeconds?.let {
            Text("بدء خلال $it...", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
        }

        Text("الحالة", style = MaterialTheme.typography.titleMedium)
        Text(statusText, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)

        if (pickedUri == null) {
            Spacer(Modifier.height(8.dp))
            Text(
                "أضف ملفًا صوتيًا أولًا لتفعيل الزر",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error
            )
        }
    }
}
