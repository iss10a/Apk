package com.imou.audiocontroller.ui

import android.Manifest
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.imou.audiocontroller.service.AudioLoopService

/**
 * ============================================================================
 * اقرأ قبل التعديل -- هذا هو أقصى ما يمكن فعله فعليًا لهذه الفكرة
 * ============================================================================
 * الهدف: تشغيل ملف صوتي من تطبيقنا في الخلفية، بحيث يلتقطه ميكروفون الهاتف
 * عندما يُفتح IMOU Life الرسمي ويُضغط زر Talk فيه.
 *
 * ما هو حقيقي ومضمون: التشغيل في الخلفية عبر Foreground Service
 * (`AudioLoopService`) -- يستمر الصوت حتى بعد الخروج من تطبيقنا فعليًا،
 * هذا جزء قياسي في أندرويد ولا حيلة فيه.
 *
 * ما هو غير ممكن برمجيًا: لا توجد طريقة على أندرويد لجعل صوت تطبيقنا "مصدر
 * ميكروفون" رسمي يقرأه IMOU Life بدلًا من الميكروفون الفعلي -- لا يوجد API
 * عام لهذا، لا في أندرويد ولا في أي مكان موثّق من Imou. الطريقة الوحيدة
 * التي تعمل فعليًا هي **صوتية/فيزيائية**: صوت عالٍ يخرج من سماعة ثم يلتقطه
 * الميكروفون الفعلي، تمامًا كأنك تتكلم بصوت عالٍ بجانبه.
 *
 * ⚠️ تحذير تقني مهم: لو شغّلت الصوت من سماعة **نفس الهاتف** اللي عليه
 * IMOU Life، فمن المتوقع أن يُضعِف أو يُلغي نظامُ إلغاء صدى الصوت
 * (Acoustic Echo Cancellation) الموجود في أغلب الهواتف هذا الصوتَ تلقائيًا،
 * لأنه مصمم خصيصًا لإزالة صوت سماعة الجهاز من إشارة ميكروفون نفس الجهاز.
 * **للحصول على أفضل نتيجة: استخدم سماعة بلوتوث/سلكية خارجية، أو هاتفًا
 * ثانيًا للتشغيل، وضعه قريبًا من ميكروفون الهاتف الذي عليه IMOU Life.**
 */
@Composable
fun MicButtonScreen() {
    val context = LocalContext.current

    var pickedUri by remember { mutableStateOf<Uri?>(null) }
    var pickedFileName by remember { mutableStateOf<String?>(null) }
    var delayText by remember { mutableStateOf("5") }
    var repeatsText by remember { mutableStateOf("3") }
    var continuous by remember { mutableStateOf(false) }

    val playback by AudioLoopService.playbackState.collectAsState()
    val running = playback.running

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    it, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            pickedUri = it
            pickedFileName = it.lastPathSegment
        }
    }

    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    fun startPlayback() {
        val uri = pickedUri ?: return
        val delaySeconds = delayText.toIntOrNull() ?: 0
        val totalRepeats = repeatsText.toIntOrNull()?.coerceAtLeast(1) ?: 1
        AudioLoopService.start(context, uri, delaySeconds, totalRepeats, continuous)
    }

    fun stopPlayback() {
        AudioLoopService.stop(context)
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(20.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("تدريب الببغاء", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(
            "يستمر التشغيل في الخلفية حتى بعد فتح IMOU Life — اضغط Talk هناك أثناء التشغيل",
            style = MaterialTheme.typography.bodySmall,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("الملف الصوتي", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        enabled = !running,
                        onClick = { filePicker.launch(arrayOf("audio/*")) }
                    ) { Text("اختيار ملف MP3/WAV") }
                    Spacer(Modifier.width(10.dp))
                    Text(pickedFileName ?: "لا يوجد ملف بعد", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("الإعدادات", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = delayText,
                    onValueChange = { if (it.all(Char::isDigit)) delayText = it },
                    label = { Text("الانتظار قبل كل تشغيل (ثوانٍ)") },
                    enabled = !running,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = repeatsText,
                    onValueChange = { if (it.all(Char::isDigit)) repeatsText = it },
                    label = { Text("عدد التكرارات") },
                    enabled = !running && !continuous,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = continuous, onCheckedChange = { if (!running) continuous = it })
                    Text("تكرار مستمر (حتى الضغط إيقاف)")
                }
            }
        }

        Spacer(Modifier.height(28.dp))

        val buttonColor = if (running) Color(0xFFD32F2F) else MaterialTheme.colorScheme.primary
        Box(
            modifier = Modifier
                .size(110.dp)
                .clip(CircleShape)
                .background(buttonColor)
                .clickable(enabled = pickedUri != null) {
                    if (running) {
                        stopPlayback()
                    } else {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                        startPlayback()
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = if (running) "■" else "🎙️",
                fontSize = 40.sp,
                color = Color.White
            )
        }

        Spacer(Modifier.height(16.dp))
        Text("الحالة", style = MaterialTheme.typography.titleMedium)
        Text(playback.status, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)

        if (pickedUri == null) {
            Spacer(Modifier.height(8.dp))
            Text(
                "أضف ملفًا صوتيًا أولًا لتفعيل الزر",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error
            )
        }

        Spacer(Modifier.height(28.dp))
        Divider()
        Spacer(Modifier.height(12.dp))
        Text(
            "كيف يصل الصوت فعليًا لكاميرا IMOU: لا توجد طريقة برمجية تجعل صوت " +
            "تطبيقنا \"ميكروفونًا\" رسميًا لتطبيق IMOU Life — هذا غير مدعوم في " +
            "أندرويد. الطريقة الوحيدة التي تعمل اليوم: شغّل الصوت من سماعة، " +
            "ثم افتح IMOU Life واضغط Talk بحيث يلتقط ميكروفونه الفعلي الصوتَ " +
            "صوتيًا (تمامًا كأنك تتكلم بصوت عالٍ).",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "⚠️ إن شغّلته من سماعة نفس الهاتف الذي عليه IMOU Life، فقد يُضعِف " +
            "إلغاء صدى الصوت (AEC) النتيجة تلقائيًا. للحصول على أفضل نتيجة: " +
            "استخدم سماعة خارجية (بلوتوث/سلكية) أو هاتفًا ثانيًا للتشغيل، " +
            "بجانب ميكروفون الهاتف الذي عليه IMOU Life.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.error
        )
    }
}
