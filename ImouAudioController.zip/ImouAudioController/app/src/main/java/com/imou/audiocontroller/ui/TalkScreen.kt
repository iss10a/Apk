package com.imou.audiocontroller.ui

import android.Manifest
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.imou.audiocontroller.audio.AudioFileDecoder
import com.imou.audiocontroller.audio.MicCapture
import com.imou.audiocontroller.talk.AudioCodec
import com.imou.audiocontroller.talk.FileSinkTalkTransport
import com.imou.audiocontroller.talk.ImouP2PTalkTransport
import com.imou.audiocontroller.talk.TalkCodec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun TalkScreen(deviceId: String?) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var pickedFileName by remember { mutableStateOf<String?>(null) }
    var pickedUri by remember { mutableStateOf<Uri?>(null) }
    var status by remember { mutableStateOf("جاهز") }
    var cameraHost by remember { mutableStateOf("") }
    var micTesting by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(0f) }
    var volumeGain by remember { mutableStateOf(1.0f) }

    val micCapture = remember { MicCapture() }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            pickedUri = it
            pickedFileName = it.lastPathSegment
        }
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            micTesting = true
            status = "اختبار الميكروفون جارٍ (محليًا فقط، لم يُرسل شيء بعد للكاميرا)"
            micCapture.start { /* chunk received; wiring to transport is the same TODO as file playback */ }
        } else {
            status = "تم رفض إذن الميكروفون"
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("التحكم بالصوت — الجهاز: ${deviceId ?: "?"}", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = cameraHost, onValueChange = { cameraHost = it },
            label = { Text("عنوان IP المحلي للكاميرا (اختياري لهذا الـPoC)") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))

        Row {
            Button(onClick = {
                if (micTesting) {
                    micCapture.stop(); micTesting = false; status = "توقف اختبار الميكروفون"
                } else {
                    micPermission.launch(Manifest.permission.RECORD_AUDIO)
                }
            }) { Text(if (micTesting) "إيقاف اختبار الميكروفون" else "اختبار Talk بالميكروفون") }
        }

        Spacer(Modifier.height(16.dp))
        Divider()
        Spacer(Modifier.height(16.dp))

        Text("ملف صوتي (WAV / MP3 / M4A)", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Button(onClick = {
            filePicker.launch(arrayOf("audio/wav", "audio/x-wav", "audio/mpeg", "audio/mp4", "audio/*"))
        }) { Text("اختيار ملف") }

        pickedFileName?.let { Text("الملف المختار: $it") }

        Spacer(Modifier.height(12.dp))
        Slider(value = volumeGain, onValueChange = { volumeGain = it }, valueRange = 0.5f..3f)
        Text("Volume gain: ${"%.1f".format(volumeGain)} (يُطبَّق فقط إذا سمح البروتوكول به)")

        Spacer(Modifier.height(12.dp))
        LinearProgressIndicator(progress = progress, modifier = Modifier.fillMaxWidth())

        Spacer(Modifier.height(12.dp))
        Row {
            Button(
                enabled = pickedUri != null,
                onClick = {
                    scope.launch {
                        status = "جارٍ فك الترميز إلى PCM..."
                        progress = 0.1f
                        try {
                            val decoded = withContext(Dispatchers.IO) { AudioFileDecoder.decode(context, pickedUri!!) }
                            progress = 0.4f
                            status = "PCM جاهز: ${decoded.pcm.size} bytes @ ${decoded.sampleRateHz}Hz/${decoded.channelCount}ch. جارٍ التحويل..."

                            val mono = AudioCodec.toMono16(decoded.pcm, decoded.channelCount)
                            val resampled8k = AudioCodec.resampleMono16(mono, decoded.sampleRateHz, 8000)
                            val alaw = AudioCodec.pcm16ToALaw(resampled8k)
                            progress = 0.7f

                            val transport = if (cameraHost.isBlank()) {
                                FileSinkTalkTransport(File(context.cacheDir, "talk_output.alaw"))
                            } else {
                                ImouP2PTalkTransport(cameraHost)
                            }

                            withContext(Dispatchers.IO) {
                                transport.open(deviceId ?: "unknown", "0")
                                transport.sendAudioChunk(alaw, TalkCodec.PCMA_8000)
                                transport.close()
                            }
                            progress = 1f
                            status = "تم بنجاح (محاكاة/ملف محلي)"
                        } catch (e: NotImplementedError) {
                            status = "متوقف عند نقطة معروفة: ${e.message}"
                        } catch (e: Exception) {
                            status = "خطأ: ${e.message}"
                        }
                    }
                }
            ) { Text("Play → إرسال للكاميرا") }

            Spacer(Modifier.width(8.dp))
            Button(onClick = { progress = 0f; status = "أُعيد الضبط" }) { Text("Stop") }
        }

        Spacer(Modifier.height(16.dp))
        Text(status, style = MaterialTheme.typography.bodyMedium)

        Spacer(Modifier.height(24.dp))
        Text(
            "ملاحظة: عند ترك حقل IP فارغًا يُكتب الصوت المُرمَّز إلى ملف محلي " +
            "لإثبات أن خط الأنابيب (فك ترميز → PCM → A-law) يعمل فعليًا. " +
            "عند إدخال IP الكاميرا سيحاول التطبيق فتح قناة Talk الحقيقية، وهي غير " +
            "مكتملة حاليًا لأن التفاصيل الثنائية للبروتوكول غير متاحة لي في هذه البيئة — " +
            "راجع الـREADME.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}
