package com.imou.audiocontroller.ui

import android.Manifest
import android.media.MediaPlayer
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.imou.audiocontroller.audio.AudioFileDecoder
import com.imou.audiocontroller.audio.MicCapture
import com.imou.audiocontroller.talk.AudioCodec
import com.imou.audiocontroller.talk.DahuaLocalTalkTransport
import com.imou.audiocontroller.talk.FileSinkTalkTransport
import com.imou.audiocontroller.talk.TalkCodec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

@Composable
fun TalkScreen(deviceId: String?) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var pickedFileName by remember { mutableStateOf<String?>(null) }
    var pickedUri by remember { mutableStateOf<Uri?>(null) }
    var status by remember { mutableStateOf("جاهز") }
    var cameraHost by remember { mutableStateOf("") }
    var micTesting by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(0f) }
    var loopEnabled by remember { mutableStateOf(false) }
    var sending by remember { mutableStateOf(false) }

    val micCapture = remember { MicCapture() }
    val micChunks = remember { ByteArrayOutputStream() }
    var sendJob by remember { mutableStateOf<Job?>(null) }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            pickedUri = it
            pickedFileName = it.lastPathSegment
        }
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            micTesting = true
            micChunks.reset()
            status = "🎙️ يسجّل الآن من الميكروفون (محليًا فقط، لم يُرسل شيء للكاميرا)"
            micCapture.start { chunk -> micChunks.write(chunk) }
        } else {
            status = "تم رفض إذن الميكروفون"
        }
    }

    fun stopSending() {
        sendJob?.cancel()
        sendJob = null
        sending = false
        status = "تم الإيقاف الفوري"
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("التحكم بالصوت — الجهاز: ${deviceId ?: "?"}", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(12.dp))

        // ---- Mic talk test (real recording, real local playback proof) ----
        Text("اختبار Talk بالميكروفون", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(4.dp))
        Row {
            Button(onClick = {
                if (micTesting) {
                    micCapture.stop()
                    micTesting = false
                    scope.launch {
                        status = "جارٍ حفظ التسجيل للتحقق منه..."
                        val pcm = micChunks.toByteArray()
                        val wavFile = File(context.cacheDir, "mic_test.wav")
                        withContext(Dispatchers.IO) {
                            FileOutputStream(wavFile).use { out ->
                                AudioCodec.writeWavPcm16Mono(out, pcm, 16000)
                            }
                        }
                        status = "تم — ${pcm.size} bytes مسجّلة فعليًا من الميكروفون. اضغط ▶️ للاستماع والتأكد."
                    }
                } else {
                    micPermission.launch(Manifest.permission.RECORD_AUDIO)
                }
            }) { Text(if (micTesting) "إيقاف التسجيل" else "🎙️ ابدأ اختبار الميكروفون") }

            Spacer(Modifier.width(8.dp))
            Button(
                enabled = !micTesting && File(context.cacheDir, "mic_test.wav").exists(),
                onClick = {
                    val player = MediaPlayer()
                    player.setDataSource(File(context.cacheDir, "mic_test.wav").absolutePath)
                    player.prepare()
                    player.start()
                    status = "▶️ يُشغّل التسجيل المحلي للتحقق منه"
                }
            ) { Text("▶️ تشغيل للتأكد") }
        }
        Text(
            "هذا اختبار حقيقي (AudioRecord قياسي) يثبت أن الميكروفون والتقاط الصوت يعملان، " +
            "لكنه لا يُرسل أي شيء للكاميرا فعليًا — LCOpenSDK لا يوفّر أي واجهة لحقن صوت خارجي " +
            "في playTalk()، فقط تشغيل ميكروفون الجهاز نفسه داخليًا.",
            style = MaterialTheme.typography.bodySmall
        )

        Spacer(Modifier.height(16.dp))
        Divider()
        Spacer(Modifier.height(16.dp))

        // ---- File -> (attempted) camera speaker ----
        Text("ملف صوتي (WAV / MP3 / M4A)", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Button(onClick = {
            filePicker.launch(arrayOf("audio/wav", "audio/x-wav", "audio/mpeg", "audio/mp4", "audio/*"))
        }) { Text("اختيار ملف") }

        pickedFileName?.let { Text("الملف المختار: $it") }

        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = cameraHost, onValueChange = { cameraHost = it },
            label = { Text("IP المحلي للكاميرا على الشبكة (لتجربة منفذ 37777 فقط — انظر الملاحظة أسفله)") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = loopEnabled, onCheckedChange = { loopEnabled = it })
            Text("Loop مستمر (يعيد المسار حتى الضغط على Stop)")
        }

        Spacer(Modifier.height(8.dp))
        LinearProgressIndicator(progress = progress, modifier = Modifier.fillMaxWidth())

        Spacer(Modifier.height(12.dp))
        Row {
            Button(
                enabled = pickedUri != null && !sending,
                onClick = {
                    sending = true
                    sendJob = scope.launch {
                        try {
                            do {
                                status = "جارٍ فك الترميز إلى PCM..."
                                progress = 0.1f
                                val decoded = withContext(Dispatchers.IO) { AudioFileDecoder.decode(context, pickedUri!!) }
                                if (!isActive) break
                                progress = 0.4f
                                status = "PCM جاهز: ${decoded.pcm.size} bytes @ ${decoded.sampleRateHz}Hz/${decoded.channelCount}ch. جارٍ التحويل..."

                                val mono = AudioCodec.toMono16(decoded.pcm, decoded.channelCount)
                                val resampled8k = AudioCodec.resampleMono16(mono, decoded.sampleRateHz, 8000)
                                val alaw = AudioCodec.pcm16ToALaw(resampled8k)
                                progress = 0.7f
                                if (!isActive) break

                                if (cameraHost.isBlank()) {
                                    // Honest path: no real transport is available (see
                                    // ImouTalkTransport.kt). Prove the pipeline works by
                                    // writing the final encoded bytes to a local file --
                                    // this NEVER reaches the camera and must not be
                                    // reported as "sent".
                                    val transport = FileSinkTalkTransport(File(context.cacheDir, "talk_output.alaw"))
                                    withContext(Dispatchers.IO) {
                                        transport.open(deviceId ?: "unknown", "0")
                                        transport.sendAudioChunk(alaw, TalkCodec.PCMA_8000)
                                        transport.close()
                                    }
                                    progress = 1f
                                    status = "✅ الترميز اكتمل ✅ — لكن ⚠️ لم يصل الصوت إلى الكاميرا فعليًا " +
                                        "(كُتب محليًا فقط في talk_output.alaw لإثبات أن خط الأنابيب يعمل). " +
                                        "لا يوجد API موثّق في LCOpenSDK لحقن ملف صوتي — راجع الملاحظة أسفله."
                                } else {
                                    // Attempt the one real, documented alternative
                                    // (Dahua local-protocol talk) -- will throw a clear
                                    // NotImplementedError until the real byte framing is
                                    // ported in (see DahuaLocalTalkTransport doc).
                                    val transport = DahuaLocalTalkTransport(cameraHost)
                                    withContext(Dispatchers.IO) {
                                        transport.open(deviceId ?: "unknown", "0")
                                        transport.sendAudioChunk(alaw, TalkCodec.PCMA_8000)
                                        transport.close()
                                    }
                                }
                                if (!loopEnabled) break
                            } while (isActive)
                        } catch (e: NotImplementedError) {
                            status = "⚠️ لم يصل الصوت إلى الكاميرا: ${e.message}"
                        } catch (e: kotlinx.coroutines.CancellationException) {
                            status = "تم الإيقاف"
                        } catch (e: Exception) {
                            status = "خطأ: ${e.message}"
                        } finally {
                            sending = false
                        }
                    }
                }
            ) { Text(if (sending) "جارٍ الإرسال..." else "Play → إرسال للكاميرا") }

            Spacer(Modifier.width(8.dp))
            Button(enabled = sending, onClick = { stopSending() }) { Text("⏹ Stop") }
        }

        Spacer(Modifier.height(16.dp))
        Text(status, style = MaterialTheme.typography.bodyMedium)

        Spacer(Modifier.height(24.dp))
        Text(
            "لماذا لا يصل الصوت فعليًا للكاميرا: LCOpenSDK الرسمي (playTalk/stopTalk) لا يملك " +
            "أي دالة لإرسال بايتات صوت خارجية — فقط يشغّل ميكروفون الهاتف داخليًا. البديل الوحيد " +
            "الحقيقي المعروف هو بروتوكول Dahua المحلي الخاص (منفذ 37777، CLIENT_TalkSendData في " +
            "NetSDK)، وهو غير مؤكد أن كاميرا Imou الاستهلاكية هذه (IPC-S41FE-7E4F) تدعمه أصلًا على " +
            "الشبكة المحلية. التفاصيل والمصادر والخطوة التالية الحقيقية موجودة في تعليقات " +
            "ImouTalkTransport.kt وREADME.md.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}
