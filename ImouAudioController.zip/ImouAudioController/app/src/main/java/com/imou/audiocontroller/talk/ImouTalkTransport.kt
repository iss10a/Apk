package com.imou.audiocontroller.talk

/**
 * Abstraction over "send encoded audio to a camera speaker". Kept separate
 * from AudioInput (mic / file) exactly as requested, so a different/real
 * transport implementation can be swapped in without touching the UI or
 * the decode/encode pipeline (AudioFileDecoder, AudioCodec).
 */
interface ImouTalkTransport {
    /** Opens the talk channel to a given device/channel. */
    fun open(deviceSerial: String, channelId: String)

    /** Sends one chunk of already-encoded audio (A-law or AAC/ADTS, per [codec]). */
    fun sendAudioChunk(chunk: ByteArray, codec: TalkCodec)

    fun close()
}

enum class TalkCodec { PCMA_8000, AAC_ADTS_16000 }

/**
 * Talk parameters as *documented in the README* of the open-source reference
 * project (home-assistant-tools/imou-life). These are the only concrete,
 * citable facts about the protocol I was able to obtain in this environment:
 *
 *   - Camera-side talk port: 8086 (both the "P2P TTS" and the LAN/Frigate
 *     talkback profile use this port).
 *   - Relay/session "type 0" is the one documented as working; "type 1" is
 *     explicitly called out as unreliable.
 *   - Two audio codec profiles are documented: G.711 A-law (PCMA) at 8000 Hz,
 *     and AAC/ADTS at 16000 Hz. Codec choice is per-camera, not universal.
 *   - The underlying transport for the "P2P TTS" profile is Dahua's DHP2P
 *     relay; for LAN cameras it's a direct TCP/HTTP session to the camera's
 *     own IP on the same port, using what the project calls "DHHTTP
 *     visualtalk.xav".
 *
 * WHAT IS **NOT** VERIFIED, because I do not have access to the actual
 * source files of that project (only its public README -- GitHub's file
 * viewer for individual source files was not retrievable with the tools
 * available to me in this environment, and this sandbox has no general
 * internet access to `git clone` the repository):
 *   - The exact byte-level packet/session framing for DHP2P "type 0" (packet
 *     header layout, magic bytes, sequence numbers, any encryption/XOR).
 *   - The exact HTTP request line/headers/body used for
 *     "DHHTTP visualtalk.xav" on LAN cameras.
 *   - Any device-serial-to-session negotiation steps needed before audio can
 *     be streamed (login handshake specific to the talk channel, as opposed
 *     to the Open API accessToken used for login/device-list).
 *
 * Implementing those bytes without the primary source would mean guessing --
 * exactly the "fake API" you told me not to build. So this class opens a
 * real TCP socket to the documented host:port and prepares correctly-encoded
 * audio (see AudioCodec.kt), but the actual `write()` calls that would frame
 * and push bytes into the camera's talk channel are left as a single, clearly
 * marked integration point (see sendAudioChunk). Once you can share the
 * relevant source file(s) from the reference project (e.g. its P2P talk
 * client module and `docs/talk-protocol-reverse-engineering.md`), I can fill
 * this in with the verified byte layout instead of a placeholder.
 */
class ImouP2PTalkTransport(
    private val cameraHost: String,
    private val cameraPort: Int = 8086
) : ImouTalkTransport {

    private var socket: java.net.Socket? = null

    override fun open(deviceSerial: String, channelId: String) {
        socket = java.net.Socket()
        socket!!.connect(java.net.InetSocketAddress(cameraHost, cameraPort), 5000)
        // TODO(protocol): send the DHP2P/DHHTTP session-open handshake here.
        // Not implemented -- see class doc. Needs the reference project's
        // actual source to avoid inventing an API.
        throw NotImplementedError(
            "Talk channel handshake for $deviceSerial/$channelId is not implemented: " +
            "the byte-level protocol is not available to this build environment. " +
            "See ImouP2PTalkTransport's class documentation."
        )
    }

    override fun sendAudioChunk(chunk: ByteArray, codec: TalkCodec) {
        val s = socket ?: error("open() was not called or failed")
        // TODO(protocol): frame `chunk` per DHP2P/DHHTTP and s.getOutputStream().write(...).
        throw NotImplementedError("Audio frame write is not implemented -- see class documentation.")
    }

    override fun close() {
        socket?.close()
        socket = null
    }
}

/**
 * A transport you CAN run today, with zero unverified protocol guesses:
 * it writes the encoded audio to a local file instead of a camera, so the
 * rest of the pipeline (login -> device list -> pick file -> decode -> PCM
 * -> codec conversion -> chunking) can be exercised and demoed end-to-end
 * on-device while the real transport above is being completed.
 */
class FileSinkTalkTransport(private val outputFile: java.io.File) : ImouTalkTransport {
    private var stream: java.io.FileOutputStream? = null

    override fun open(deviceSerial: String, channelId: String) {
        stream = java.io.FileOutputStream(outputFile)
    }

    override fun sendAudioChunk(chunk: ByteArray, codec: TalkCodec) {
        stream?.write(chunk)
    }

    override fun close() {
        stream?.close()
        stream = null
    }
}
