package com.imou.audiocontroller.talk

/**
 * Abstraction over "send encoded audio to a camera speaker". Kept separate
 * from AudioInput (mic / file) exactly as requested, so a different/real
 * transport implementation can be swapped in without touching the UI or
 * the decode/encode pipeline (AudioFileDecoder, AudioCodec).
 */
interface ImouTalkTransport {
    /** Opens the talk channel to a given device/channel. */
    fun open(deviceSerial: String, channelId: String)

    /** Sends one chunk of already-encoded audio (A-law or AAC/ADTS, per [codec]). */
    fun sendAudioChunk(chunk: ByteArray, codec: TalkCodec)

    fun close()
}

enum class TalkCodec { PCMA_8000, AAC_ADTS_16000 }

/**
 * ============================================================================
 * STATUS OF "FILE -> CAMERA SPEAKER" (re-verified this session, independently
 * of the prior research you pasted -- same conclusion, from primary sources):
 * ============================================================================
 *
 * 1) LCOpenSDK (Imou's official closed-source Android/iOS SDK) -- CONFIRMED
 *    it has no audio-injection API. Its entire Talk surface, per Imou's own
 *    published integration guide (open.imoulife.com/book/mobile/android/sdk.html,
 *    matching open.imou.com/document/pages/0a8eaa/), is exactly:
 *        LCOpenSDK_Talk.setListener(TalkerListener)
 *        LCOpenSDK_Talk.playTalk(ParamTalk)   // params: accessToken, deviceID,
 *                                              // channel, psk, playToken -- NO audio field
 *        LCOpenSDK_Talk.stopTalk()
 *    There is no sendAudio/pushAudioFrame/writeAudioFrame/onRequestAudioData
 *    anywhere in the documented surface. The mic capture that playTalk() uses
 *    happens inside the closed .aar binary. This project does not even bundle
 *    that .aar (it isn't public and this sandbox has no way to obtain it), so
 *    LCOpenSDK is not used anywhere in this codebase. Live View / video
 *    playback was intentionally removed from this simplified build; only
 *    login, device list, and the audio-training pipeline remain.
 *
 * 2) The ONE real, citable, non-invented alternative found: Dahua's separate,
 *    general-purpose "NetSDK" (the C SDK used by Dahua/Lechange NVR client
 *    software, NOT the Imou cloud OpenSDK) documents a real local-network
 *    audio-push API for exactly this purpose:
 *        CLIENT_SetDeviceMode(..., DH_TALK_ENCODE_TYPE)
 *        CLIENT_StartTalkEx(...)   // opens the talk channel
 *        CLIENT_TalkSendData(...)  // sends caller-supplied PCM/encoded audio bytes
 *        CLIENT_StopTalkEx(...)
 *    (source: Dahua "NetSDK Programming Manual", section 2.7 "Voice Talk").
 *    Independently, a third party has published an open-source (MIT-licensed,
 *    Go) reimplementation of the same wire protocol without needing that C
 *    SDK at all -- see AlexxIT/go2rtc pull request #2431, "Add native Dahua
 *    two-way audio backchannel (TCP/37777)", which speaks the raw DHAV frame
 *    format directly over TCP port 37777 and has been confirmed working by a
 *    second, independent user on real hardware (an IPC-HDBW5449 rebrand).
 *
 *    IMPORTANT CAVEATS, stated plainly rather than papered over:
 *      - That PR itself notes the 37777 talk channel may require the device's
 *        "Private Protocol Authentication Mode" to be set to "Compatible" --
 *        a LOCAL LAN, non-cloud access path, separate from the Imou Open
 *        Platform account/token this app otherwise uses.
 *      - Every device confirmed working in that thread is a Dahua-branded or
 *        Dahua-OEM PoE camera. It is NOT verified whether a consumer Imou
 *        Wi-Fi camera (IPC-S41FE-7E4F) exposes port 37777 / the private
 *        protocol at all on its LAN interface -- Imou consumer firmware is
 *        commonly cloud/P2P-only. This must be checked against your actual
 *        camera (e.g. `nmap -p 37777 <camera-ip>`) before any of this is
 *        worth implementing.
 *      - I only have that PR's *description* in this environment, not its
 *        actual Go source files (fetching individual files off GitHub needs
 *        each raw-file URL, which I don't have yet). Porting the exact DHAV
 *        byte-level framing from Go to Kotlin without the real source would
 *        be exactly the "invented protocol" you told me not to write.
 *
 *    NEXT STEP if you want to pursue this for real: confirm port 37777 is
 *    reachable on the camera's LAN IP, then get me the actual source files
 *    from that PR/branch (stream-z:feat/dahua-backchannel in AlexxIT/go2rtc,
 *    package pkg/dahua) -- with the real DHAV framing in hand, this class can
 *    be filled in against verified bytes instead of a placeholder.
 *
 * Until one of the above is actually in hand, `open()`/`sendAudioChunk()`
 * below throw a clearly labeled NotImplementedError instead of a fabricated
 * request -- exactly as before.
 */
class DahuaLocalTalkTransport(
    private val cameraHost: String,
    private val cameraPort: Int = 37777
) : ImouTalkTransport {

    private var socket: java.net.Socket? = null

    override fun open(deviceSerial: String, channelId: String) {
        socket = java.net.Socket()
        socket!!.connect(java.net.InetSocketAddress(cameraHost, cameraPort), 5000)
        throw NotImplementedError(
            "DHAV talk handshake for $deviceSerial/$channelId is not implemented: " +
            "the byte-level DHAV framing is not available to this build environment " +
            "(only the go2rtc PR #2431 description was retrievable, not its source). " +
            "See this class's documentation for the exact, real next step."
        )
    }

    override fun sendAudioChunk(chunk: ByteArray, codec: TalkCodec) {
        val s = socket ?: error("open() was not called or failed")
        throw NotImplementedError("DHAV audio frame write is not implemented -- see class documentation.")
    }

    override fun close() {
        socket?.close()
        socket = null
    }
}

/** Kept as a compatibility alias so existing call sites/tests don't break. */
@Deprecated("Renamed to DahuaLocalTalkTransport to reflect what it actually targets.", ReplaceWith("DahuaLocalTalkTransport"))
typealias ImouP2PTalkTransport = DahuaLocalTalkTransport

/**
 * A transport you CAN run today, with zero unverified protocol guesses:
 * it writes the encoded audio to a local file instead of a camera, so the
 * rest of the pipeline (login -> device list -> pick file -> decode -> PCM
 * -> codec conversion -> chunking) can be exercised and demoed end-to-end
 * on-device while a real transport is pending real protocol access (see
 * DahuaLocalTalkTransport doc above).
 *
 * IMPORTANT: this NEVER reaches the camera. The UI must not describe this
 * as "sent to the camera" -- only as "encoded audio pipeline verified
 * locally". See TalkScreen.kt.
 */
class FileSinkTalkTransport(private val outputFile: java.io.File) : ImouTalkTransport {
    private var stream: java.io.FileOutputStream? = null

    override fun open(deviceSerial: String, channelId: String) {
        stream = java.io.FileOutputStream(outputFile)
    }

    override fun sendAudioChunk(chunk: ByteArray, codec: TalkCodec) {
        stream?.write(chunk)
    }

    override fun close() {
        stream?.close()
        stream = null
    }
}
