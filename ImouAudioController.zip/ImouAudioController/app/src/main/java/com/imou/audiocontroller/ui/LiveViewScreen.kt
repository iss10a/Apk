package com.imou.audiocontroller.ui

import android.widget.FrameLayout
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.imou.audiocontroller.network.ImouOpenApiClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Real Live View: calls the documented `bindDeviceLive` OpenAPI method to
 * mint an HLS (.m3u8) URL for the device/channel, then plays it with
 * standard AndroidX Media3 ExoPlayer. No LCOpenSDK / native binary is
 * needed for this path -- see ImouOpenApiClient.bindDeviceLive for the
 * exact documented request/response shape this is built from.
 */
@Composable
fun LiveViewScreen(apiClient: ImouOpenApiClient?, deviceId: String, channelId: String) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf("جارٍ طلب رابط البث المباشر...") }
    var hlsUrl by remember { mutableStateOf<String?>(null) }
    var streamId by remember { mutableIntStateOf(1) } // 1 = SD (default), 0 = HD

    val exoPlayer = remember {
        ExoPlayer.Builder(context).build()
    }

    suspend fun loadLive() {
        if (apiClient == null) {
            status = "لم يتم تسجيل الدخول"
            return
        }
        status = "جارٍ طلب رابط البث (بجودة ${if (streamId == 0) "HD" else "SD"})..."
        try {
            val url = withContext(Dispatchers.IO) { apiClient.bindDeviceLive(deviceId, channelId, streamId) }
            if (url.isNullOrEmpty()) {
                status = "لم يُرجع الخادم رابط بث (قد يكون الجهاز غير متصل أو غير مخوَّل للبث السحابي)"
                return
            }
            hlsUrl = url
            exoPlayer.setMediaItem(MediaItem.fromUri(url))
            exoPlayer.prepare()
            exoPlayer.playWhenReady = true
            status = "تم — البث عبر HLS (bindDeviceLive الرسمية)"
        } catch (e: Exception) {
            status = "تعذر بدء البث: ${e.message}"
        }
    }

    LaunchedEffect(deviceId, channelId) { loadLive() }

    DisposableEffect(Unit) {
        onDispose { exoPlayer.release() }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("البث المباشر — الجهاز: $deviceId", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Text(status, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(12.dp))

        AndroidView(
            modifier = Modifier.fillMaxWidth().height(240.dp),
            factory = {
                PlayerView(context).apply {
                    player = exoPlayer
                    layoutParams = FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT
                    )
                }
            }
        )

        Spacer(Modifier.height(12.dp))
        Row {
            Button(onClick = {
                streamId = 0
                status = "جارٍ التبديل إلى HD..."
                exoPlayer.stop()
                scope.launch { loadLive() }
            }) { Text("HD") }
            Spacer(Modifier.width(8.dp))
            Button(onClick = {
                streamId = 1
                status = "جارٍ التبديل إلى SD..."
                exoPlayer.stop()
                scope.launch { loadLive() }
            }) { Text("SD") }
            Spacer(Modifier.width(8.dp))
            Button(onClick = {
                exoPlayer.stop()
                status = "أُوقف البث"
            }) { Text("إيقاف") }
        }

        Spacer(Modifier.height(16.dp))
        Text(
            "هذا البث حقيقي فعليًا: يُطلب عبر واجهة bindDeviceLive الموثّقة رسميًا " +
            "(open.imou.com) ثم يُشغَّل برابط .m3u8 القياسي عبر Media3 — لا حاجة " +
            "لأي SDK مغلق المصدر لعرض الفيديو.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}
