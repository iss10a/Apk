package com.imou.audiocontroller.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteBuffer

/** Decoded PCM result: 16-bit signed little-endian PCM plus its real format. */
data class DecodedPcm(
    val pcm: ByteArray,
    val sampleRateHz: Int,
    val channelCount: Int
)

/**
 * Decodes a user-picked WAV / MP3 / M4A file into raw 16-bit PCM using the
 * standard, documented Android MediaExtractor + MediaCodec APIs. This part
 * has no dependency on Imou at all -- it is generic Android media handling
 * and can be tested on-device independently of any camera.
 */
object AudioFileDecoder {

    fun decode(context: Context, uri: Uri): DecodedPcm {
        val extractor = MediaExtractor()
        extractor.setDataSource(context.contentResolver.openFileDescriptor(uri, "r")!!.fileDescriptor)

        var trackIndex = -1
        var format: MediaFormat? = null
        for (i in 0 until extractor.trackCount) {
            val f = extractor.getTrackFormat(i)
            val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("audio/")) {
                trackIndex = i
                format = f
                break
            }
        }
        require(trackIndex >= 0 && format != null) { "No audio track found in selected file" }
        extractor.selectTrack(trackIndex)

        val mime = format.getString(MediaFormat.KEY_MIME)!!
        val sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        val channelCount = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)

        // WAV/PCM containers can be read straight from the extractor without a codec.
        if (mime == "audio/raw" || mime == "audio/x-wav" || mime == "audio/wav") {
            val out = readAllSamples(extractor) { buf, _ -> buf }
            extractor.release()
            return DecodedPcm(out, sampleRate, channelCount)
        }

        // Compressed formats (MP3 / AAC in M4A) go through MediaCodec.
        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(format, null, null, 0)
        codec.start()

        val output = java.io.ByteArrayOutputStream()
        val bufferInfo = MediaCodec.BufferInfo()
        var sawInputEos = false
        var sawOutputEos = false

        while (!sawOutputEos) {
            if (!sawInputEos) {
                val inIndex = codec.dequeueInputBuffer(10_000)
                if (inIndex >= 0) {
                    val inBuf: ByteBuffer = codec.getInputBuffer(inIndex)!!
                    val sampleSize = extractor.readSampleData(inBuf, 0)
                    if (sampleSize < 0) {
                        codec.queueInputBuffer(inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        sawInputEos = true
                    } else {
                        codec.queueInputBuffer(inIndex, 0, sampleSize, extractor.sampleTime, 0)
                        extractor.advance()
                    }
                }
            }

            val outIndex = codec.dequeueOutputBuffer(bufferInfo, 10_000)
            if (outIndex >= 0) {
                val outBuf: ByteBuffer = codec.getOutputBuffer(outIndex)!!
                val chunk = ByteArray(bufferInfo.size)
                outBuf.position(bufferInfo.offset)
                outBuf.get(chunk)
                output.write(chunk)
                codec.releaseOutputBuffer(outIndex, false)
                if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                    sawOutputEos = true
                }
            }
        }

        codec.stop()
        codec.release()
        extractor.release()

        return DecodedPcm(output.toByteArray(), sampleRate, channelCount)
    }

    private inline fun readAllSamples(extractor: MediaExtractor, transform: (ByteArray, Int) -> ByteArray): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        val buffer = ByteBuffer.allocate(64 * 1024)
        while (true) {
            buffer.clear()
            val n = extractor.readSampleData(buffer, 0)
            if (n < 0) break
            val chunk = ByteArray(n)
            buffer.get(chunk)
            out.write(transform(chunk, n))
            extractor.advance()
        }
        return out.toByteArray()
    }
}
