package com.imou.audiocontroller.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.imou.audiocontroller.audio.AudioFileDecoder
import com.imou.audiocontroller.talk.AudioCodec
import com.imou.audiocontroller.talk.DahuaLocalTalkTransport
import com.imou.audiocontroller.talk.FileSinkTalkTransport
import com.imou.audiocontroller.talk.ImouTalkTransport
import com.imou.audiocontroller.talk.TalkCodec
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * تدريب الببغاء: يختار المستخدم تسجيلًا صوتيًا واحدًا، يحدد عدد التكرارات
 * والفاصل الزمني بينها، ثم يضغط "بدء التدريب" فيعيد التطبيق تشغيل نفس
 * التسجيل تلقائيًا بهذا العدد وبهذا الفاصل، مع إمكانية الإيقاف الفوري.
 *
 * ============================================================================
 * الوضع الحقيقي لإرسال الصوت إلى سماعة الكاميرا (تم التحقق منه في هذه الجلسة
 * من مصدرين رسميين/عامين، بالإضافة لما كان موثّقًا سابقًا في المشروع):
 * ============================================================================
 * - دليل Imou الرسمي لـ LCOpenSDK (open.imoulife.com/book/mobile/android/sdk.html
 *   و .../ios/sdk.html) يوثّق واجهة الـ Talk بالكامل كالتالي فقط:
 *       LCOpenSDK_Talk.setListener(...)
 *       LCOpenSDK_Talk.playTalk(ParamTalk)   // accessToken, deviceID, channel, psk, playToken فقط
 *       LCOpenSDK_Talk.stopTalk()
 *   لا يوجد أي حقل لإرسال بيانات صوت خارجية، ولا أي دالة sendAudio/pushAudioFrame.
 *   الـ SDK يفتح ميكروفون الهاتف نفسه داخليًا فقط.
 * - في issue عام على GitHub (user2684/imou_life#76) سأل مستخدم بالضبط نفس
 *   فكرتنا (تشغيل TTS على سماعة كاميرا IPC-S41FE عبر التطبيق)، وأجاب صاحب
 *   المشروع أنه لا يوجد في الـ API المنشور رسميًا ما يسمح بذلك، وأن هناك على
 *   الأرجح API غير منشور لكنه غير معروف الشكل.
 * => الخلاصة: لا توجد طريقة رسمية موثّقة اليوم لحقن ملف صوتي في سماعة هذه
 *    الكاميرا عبر LCOpenSDK. هذا ليس افتراضًا مني، بل نتيجة فحص فعلي للمصدرين
 *    أعلاه. البديل الوحيد المعروف (وغير المؤكد على هذا الطراز تحديدًا) هو
 *    بروتوكول Dahua المحلي على المنفذ 37777 -- انظر ImouTalkTransport.kt.
 *
 * لذلك هذه الشاشة تنفّذ خط الأنابيب بالكامل (اختيار → فك ترميز → تحويل →
 * تكرار بالعدد والفاصل المطلوبين → إيقاف فوري) بشكل حقيقي وقابل للاختبار،
 * وتحاول الإرسال عبر DahuaLocalTalkTransport إن أُدخل IP محلي للكاميرا (طريق
 * غير مؤكد الدعم على هذا الطراز)، وإلا تكتب الصوت المُرمّز محليًا فقط
 * (FileSinkTalkTransport) مع تحذير صريح أنه لم يصل فعليًا للكاميرا -- دون أي
 * ادّعاء كاذب بالنجاح.
 */
@Composable
fun TrainScreen(deviceId: String?) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var pickedUri by remember { mutableStateOf<Uri?>(null) }
    var pickedFileName by remember { mutableStateOf<String?>(null) }
    var repeatsText by remember { mutableStateOf("20") }
    var intervalText by remember { mutableStateOf("5") }
    var cameraHost by remember { mutableStateOf("") }

    var training by remember { mutableStateOf(false) }
    var currentRepeat by remember { mutableStateOf(0) }
    var status by remember { mutableStateOf("جاهز") }
    var reachedCamera by remember { mutableStateOf<Boolean?>(null) }
    var trainJob by remember { mutableStateOf<Job?>(null) }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            pickedUri = it
            pickedFileName = it.lastPathSegment
        }
    }

    fun stopTraining(message: String = "تم الإيقاف الفوري") {
        trainJob?.cancel()
        trainJob = null
        training = false
        status = message
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("تدريب الببغاء", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("الجهاز: ${deviceId ?: "?"}", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(20.dp))

        Text("التسجيل", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(
                enabled = !training,
                onClick = { filePicker.launch(arrayOf("audio/wav", "audio/x-wav", "audio/mpeg", "audio/mp4", "audio/*")) }
            ) { Text("اختيار تسجيل") }
            Spacer(Modifier.width(10.dp))
            Text(pickedFileName ?: "لم يتم اختيار ملف بعد")
        }

        Spacer(Modifier.height(20.dp))
        Row(Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = repeatsText,
                onValueChange = { if (it.all(Char::isDigit)) repeatsText = it },
                label = { Text("التكرارات") },
                enabled = !training,
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(12.dp))
            OutlinedTextField(
                value = intervalText,
                onValueChange = { if (it.all(Char::isDigit)) intervalText = it },
                label = { Text("الفاصل (ثوانٍ)") },
                enabled = !training,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = cameraHost,
            onValueChange = { cameraHost = it },
            label = { Text("IP المحلي للكاميرا (اختياري — لتجربة منفذ 37777 فقط، انظر الملاحظة أسفله)") },
            enabled = !training,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(20.dp))
        Row {
            Button(
                enabled = pickedUri != null && !training && (repeatsText.toIntOrNull() ?: 0) > 0,
                onClick = {
                    val totalRepeats = repeatsText.toIntOrNull() ?: 20
                    val intervalSeconds = intervalText.toIntOrNull() ?: 5
                    training = true
                    currentRepeat = 0
                    reachedCamera = null
                    trainJob = scope.launch {
                        var transport: ImouTalkTransport? = null
                        try {
                            status = "جارٍ فك ترميز التسجيل..."
                            val decoded = withContext(Dispatchers.IO) { AudioFileDecoder.decode(context, pickedUri!!) }
                            val mono = AudioCodec.toMono16(decoded.pcm, decoded.channelCount)
                            val resampled8k = AudioCodec.resampleMono16(mono, decoded.sampleRateHz, 8000)
                            val alaw = AudioCodec.pcm16ToALaw(resampled8k)

                            transport = if (cameraHost.isBlank()) {
                                FileSinkTalkTransport(File(context.cacheDir, "train_output.alaw"))
                            } else {
                                DahuaLocalTalkTransport(cameraHost)
                            }

                            withContext(Dispatchers.IO) { transport.open(deviceId ?: "unknown", "0") }

                            for (i in 1..totalRepeats) {
                                if (!isActive) break
                                currentRepeat = i
                                status = "التكرار $i / $totalRepeats"
                                try {
                                    withContext(Dispatchers.IO) { transport.sendAudioChunk(alaw, TalkCodec.PCMA_8000) }
                                    reachedCamera = cameraHost.isNotBlank()
                                } catch (e: NotImplementedError) {
                                    reachedCamera = false
                                    status = "⚠️ التكرار $i/$totalRepeats: لم يصل الصوت لسماعة الكاميرا فعليًا — ${e.message}"
                                }
                                if (i < totalRepeats && isActive) delay(intervalSeconds * 1000L)
                            }
                            if (isActive) {
                                status = if (reachedCamera == true) {
                                    "✅ اكتمل التدريب: $totalRepeats/$totalRepeats"
                                } else {
                                    "اكتمل خط الأنابيب محليًا ($totalRepeats/$totalRepeats) — ⚠️ لم يصل الصوت لسماعة الكاميرا فعليًا (انظر الملاحظة أسفله)"
                                }
                            }
                        } catch (e: CancellationException) {
                            status = "تم الإيقاف عند $currentRepeat/${repeatsText.toIntOrNull() ?: 20}"
                        } catch (e: Exception) {
                            status = "خطأ: ${e.message}"
                        } finally {
                            withContext(Dispatchers.IO) { runCatching { transport?.close() } }
                            training = false
                        }
                    }
                }
            ) { Text("▶ بدء التدريب") }

            Spacer(Modifier.width(8.dp))
            Button(enabled = training, onClick = { stopTraining() }) { Text("■ إيقاف") }
        }

        Spacer(Modifier.height(20.dp))
        Text("الحالة", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(4.dp))
        Text(status, style = MaterialTheme.typography.bodyMedium)

        Spacer(Modifier.height(28.dp))
        Divider()
        Spacer(Modifier.height(12.dp))
        Text(
            "لماذا قد لا يصل الصوت فعليًا لسماعة الكاميرا: تم التحقق من دليل Imou الرسمي " +
            "لـ LCOpenSDK — واجهة playTalk/stopTalk لا تملك أي حقل أو دالة لإرسال بايتات صوت " +
            "خارجية من التطبيق، بل تفتح ميكروفون الهاتف داخليًا فقط. كما لم يجد صاحب مشروع " +
            "imou_life نفسه (في نقاش عام على GitHub سُئل فيه نفس هذا السؤال بالضبط) أي API " +
            "منشور رسميًا يتيح ذلك. البديل الوحيد الحقيقي المعروف هو بروتوكول Dahua المحلي " +
            "(منفذ 37777)، وهو غير مؤكد أن هذه الكاميرا الاستهلاكية تدعمه، وتفاصيله وحدود " +
            "التنفيذ الحالية موجودة في ImouTalkTransport.kt.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}
