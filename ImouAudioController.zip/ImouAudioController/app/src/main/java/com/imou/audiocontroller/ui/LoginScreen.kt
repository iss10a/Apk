package com.imou.audiocontroller.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.imou.audiocontroller.network.ImouOpenApiClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun LoginScreen(onLoggedIn: (ImouOpenApiClient) -> Unit) {
    var appId by remember { mutableStateOf("") }
    var appSecret by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("تسجيل الدخول إلى Imou Open Platform", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Text(
            "أدخل App Id و App Secret الخاصين بحسابك على open.imoulife.com. " +
            "لا يتم تخزين هذه البيانات في المشروع أو رفعها إلى GitHub.",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(value = appId, onValueChange = { appId = it }, label = { Text("App Id") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = appSecret, onValueChange = { appSecret = it }, label = { Text("App Secret") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(16.dp))
        Button(
            enabled = appId.isNotBlank() && appSecret.isNotBlank() && !loading,
            onClick = {
                loading = true
                error = null
                scope.launch {
                    try {
                        val client = ImouOpenApiClient(appId, appSecret)
                        val ok = withContext(Dispatchers.IO) { client.login() }
                        loading = false
                        if (ok) onLoggedIn(client) else error = "فشل تسجيل الدخول: تحقق من App Id/Secret"
                    } catch (e: Exception) {
                        loading = false
                        error = "خطأ: ${e.message}"
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (loading) "جارٍ الاتصال..." else "تسجيل الدخول") }

        error?.let {
            Spacer(Modifier.height(12.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
        }
    }
}
