package com.imou.audiocontroller.network

import android.util.Base64
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.TimeUnit
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Client for the OFFICIAL, documented Imou Open Platform cloud API
 * (open.imou.com / openapi-<region>.easy4ip.com). This is NOT the
 * reverse-engineered mobile-app protocol used for two-way talk -- this
 * part of the app only needs account login and the device list, both of
 * which Imou documents and supports for third-party developers who
 * register an App Id / App Secret on https://open.imou.com.
 *
 * Signature algorithm per https://open.imou.com/document/pages/c20750/
 * (confirmed correct against the official test vector: time=1706511734,
 * nonce=f5a1ae2d-c09c-4d39-a744-83a5c2c653c2,
 * appSecret=test123456789test123456789 -> sign=xjhCQBoJ9hRDsCjyDcHjtDNzRZ3ZJezcawsfWeiaoxU=):
 *   1) SIGN_TEMPLATE = "time:{time},nonce:{nonce},appSecret:{appSecret}"
 *   2) password = LowerCase(Hex(SHA-256(appSecret)))
 *   3) sign = Base64(HMAC-SHA256(SIGN_TEMPLATE, key = password))
 *
 * deviceBaseList / deviceBaseDetailList params confirmed against the official
 * doc (open.imoulife.com/book/http/device/manage/query/deviceBaseList.html and
 * .../deviceBaseDetailList.html) and cross-checked against the imouapi
 * reference client source (async_api_deviceBaseList / async_api_deviceBaseDetailList
 * in imouapi/api.py). Both endpoints live on the exact same host
 * (openapi-[DataCenter].easy4ip.com) this client already uses for login, so
 * no platform/signature change was needed -- only the request body was wrong.
 *
 * IMPORTANT: deviceBaseList itself returns only bindId/deviceId/channels/aplist,
 * NOT deviceName/status/deviceModel. Those fields only come back from
 * deviceBaseDetailList (called per batch of deviceIds), so listing devices is a
 * two-step call: listDevices() for the id list, then listDeviceDetails(ids) to
 * enrich each one with name/model/status.
 */
class ImouOpenApiClient(
    private val appId: String,
    private val appSecret: String,
    private val host: String = "openapi-sg.easy4ip.com"
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private var accessToken: String? = null

    /** SHA-256(appSecret), lowercase hex -- used as the HMAC key, per the official algorithm. */
    private fun sha256HexLower(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    /** sign = Base64(HMAC-SHA256("time:{time},nonce:{nonce},appSecret:{appSecret}", key=password)). */
    private fun calcSign(time: Long, nonce: String): String {
        val signTemplate = "time:$time,nonce:$nonce,appSecret:$appSecret"
        val password = sha256HexLower(appSecret)
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(password.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        val digest = mac.doFinal(signTemplate.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(digest, Base64.NO_WRAP)
    }

    private fun buildEnvelope(params: JSONObject): JSONObject {
        val time = System.currentTimeMillis() / 1000
        val nonce = UUID.randomUUID().toString()
        val sign = calcSign(time, nonce)

        val system = JSONObject()
            .put("ver", "1.0")
            .put("appId", appId)
            .put("sign", sign)
            .put("time", time)
            .put("nonce", nonce)

        return JSONObject()
            .put("system", system)
            .put("id", UUID.randomUUID().toString())
            .put("params", params)
    }

    private fun call(method: String, params: JSONObject): JSONObject {
        val body = buildEnvelope(params).toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
            .url("https://$host/openapi/$method")
            .post(body)
            .build()
        client.newCall(request).execute().use { resp ->
            val text = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                throw ImouApiException("HTTP ${resp.code} calling $method: $text")
            }
            val json = JSONObject(text)
            val result = json.optJSONObject("result")
            val code = result?.optString("code") ?: json.optString("code", "")
            if (code.isNotEmpty() && code != "0") {
                throw ImouApiException("Imou API error ($method): code=$code body=$text")
            }
            return json
        }
    }

    /** Logs in (obtains an accessToken) using the App Id / App Secret entered by the user in-app. */
    fun login(): Boolean {
        val json = call("accessToken", JSONObject())
        val result = json.optJSONObject("result") ?: json
        val data = result.optJSONObject("data")
        val token = data?.optString("accessToken")
        accessToken = token
        return !token.isNullOrEmpty()
    }

    /** Every authenticated call needs the current accessToken injected into params as "token". */
    private fun withToken(params: JSONObject): JSONObject {
        check(accessToken != null) { "Call login() first" }
        return params.put("token", accessToken)
    }

    /**
     * Returns the raw device list JSON as documented by deviceBaseList:
     * { bindId:-1, limit:50, type:"bindAndShare", needApInfo:true }.
     * "bindAndShare" returns both devices you own and devices shared with you;
     * use "bind" instead if you only want devices you directly bound.
     * Only contains deviceId/channels/aplist -- call listDeviceDetails() for
     * name/model/status.
     */
    fun listDevices(): JSONObject {
        val params = withToken(
            JSONObject()
                .put("bindId", -1)
                .put("limit", 50)
                .put("type", "bindAndShare")
                .put("needApInfo", true)
        )
        return call("deviceBaseList", params)
    }

    /**
     * Returns deviceName/status/deviceModel/etc for the given device ids, as
     * documented by deviceBaseDetailList. Pass the deviceIds obtained from
     * listDevices().
     */
    fun listDeviceDetails(deviceIds: List<String>): JSONObject {
        val deviceList = JSONArray()
        deviceIds.forEach { id ->
            deviceList.put(JSONObject().put("deviceId", id).put("channelList", "0"))
        }
        val params = withToken(JSONObject().put("deviceList", deviceList))
        return call("deviceBaseDetailList", params)
    }

}

class ImouApiException(message: String) : Exception(message)
