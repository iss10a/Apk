package com.imou.audiocontroller.network

import android.util.Base64
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.TimeUnit
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Client for the OFFICIAL, documented Imou Open Platform cloud API
 * (open.imou.com / openapi-<region>.easy4ip.com). This is NOT the
 * reverse-engineered mobile-app protocol used for two-way talk -- this
 * part of the app only needs account login and the device list, both of
 * which Imou documents and supports for third-party developers who
 * register an App Id / App Secret on https://open.imou.com.
 *
 * Signature algorithm per https://open.imou.com/document/pages/c20750/
 * (confirmed correct against the official test vector: time=1706511734,
 * nonce=f5a1ae2d-c09c-4d39-a744-83a5c2c653c2,
 * appSecret=test123456789test123456789 -> sign=xjhCQBoJ9hRDsCjyDcHjtDNzRZ3ZJezcawsfWeiaoxU=):
 *   1) SIGN_TEMPLATE = "time:{time},nonce:{nonce},appSecret:{appSecret}"
 *   2) password = LowerCase(Hex(SHA-256(appSecret)))
 *   3) sign = Base64(HMAC-SHA256(SIGN_TEMPLATE, key = password))
 *
 * deviceBaseList's exact required parameters are NOT independently verified
 * by me -- if it returns OP1002 ("Parameter missing"), please paste the
 * relevant open.imou.com doc page (the way you did for accessToken/signing)
 * so the params below get fixed against the real spec instead of guessed.
 */
class ImouOpenApiClient(
    private val appId: String,
    private val appSecret: String,
    private val host: String = "openapi-sg.easy4ip.com"
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private var accessToken: String? = null

    /** SHA-256(appSecret), lowercase hex -- used as the HMAC key, per the official algorithm. */
    private fun sha256HexLower(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    /** sign = Base64(HMAC-SHA256("time:{time},nonce:{nonce},appSecret:{appSecret}", key=password)). */
    private fun calcSign(time: Long, nonce: String): String {
        val signTemplate = "time:$time,nonce:$nonce,appSecret:$appSecret"
        val password = sha256HexLower(appSecret)
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(password.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        val digest = mac.doFinal(signTemplate.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(digest, Base64.NO_WRAP)
    }

    private fun buildEnvelope(params: JSONObject): JSONObject {
        val time = System.currentTimeMillis() / 1000
        val nonce = UUID.randomUUID().toString()
        val sign = calcSign(time, nonce)

        val system = JSONObject()
            .put("ver", "1.0")
            .put("appId", appId)
            .put("sign", sign)
            .put("time", time)
            .put("nonce", nonce)

        return JSONObject()
            .put("system", system)
            .put("id", UUID.randomUUID().toString())
            .put("params", params)
    }

    private fun call(method: String, params: JSONObject): JSONObject {
        val body = buildEnvelope(params).toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
            .url("https://$host/openapi/$method")
            .post(body)
            .build()
        client.newCall(request).execute().use { resp ->
            val text = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                throw ImouApiException("HTTP ${resp.code} calling $method: $text")
            }
            val json = JSONObject(text)
            val result = json.optJSONObject("result")
            val code = result?.optString("code") ?: json.optString("code", "")
            if (code.isNotEmpty() && code != "0") {
                throw ImouApiException("Imou API error ($method): code=$code body=$text")
            }
            return json
        }
    }

    /** Logs in (obtains an accessToken) using the App Id / App Secret entered by the user in-app. */
    fun login(): Boolean {
        val json = call("accessToken", JSONObject())
        val result = json.optJSONObject("result") ?: json
        val data = result.optJSONObject("data")
        val token = data?.optString("accessToken")
        accessToken = token
        return !token.isNullOrEmpty()
    }

    /** Returns the raw device list JSON as documented by deviceBaseList. Parsing into ImouDevice is left to the caller/UI layer. */
    fun listDevices(): JSONObject {
        check(accessToken != null) { "Call login() first" }
        val params = JSONObject().put("token", accessToken).put("pageNo", 1).put("pageSize", 50)
        return call("deviceBaseList", params)
    }
}

class ImouApiException(message: String) : Exception(message)
