package com.imou.audiocontroller.network

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.TimeUnit

/**
 * Client for the OFFICIAL, documented Imou Open Platform cloud API
 * (open.imoulife.com / openapi-<region>.easy4ip.com). This is NOT the
 * reverse-engineered mobile-app protocol used for two-way talk -- this
 * part of the app only needs account login and the device list, both of
 * which Imou documents and supports for third-party developers who
 * register an App Id / App Secret on https://open.imoulife.com.
 *
 * VERIFIED from public sources:
 *  - Endpoint shape: POST https://<host>/openapi/<method>
 *  - Regional hosts include openapi-sg.easy4ip.com (confirmed in the
 *    official Flutter plugin "imou_plugin" and the Python "pyimouapi" client).
 *  - Envelope shape: { "system": { "ver", "appId", "sign", "time", "nonce" },
 *                       "id": "<random>", "params": { ... } }
 *
 * NOT independently verified by me (I could not fetch the exact primary
 * source string used to build "sign"): the literal concatenation format
 * fed into MD5 before hex-encoding. The pattern below ("time:{time},nonce:{nonce},appSecret:{appSecret}")
 * matches the shape used by comparable Chinese IoT open platforms and by
 * the public imou_plugin sample, but you MUST confirm it against your own
 * Imou Open Platform console ("API docs" -> "Signature") before relying on
 * it for anything beyond this proof of concept. If accessToken calls fail
 * with a signature error, this is the first thing to check.
 */
class ImouOpenApiClient(
    private val appId: String,
    private val appSecret: String,
    private val host: String = "openapi-sg.easy4ip.com"
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private var accessToken: String? = null

    private fun md5Hex(input: String): String {
        val digest = MessageDigest.getInstance("MD5").digest(input.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    private fun buildEnvelope(params: JSONObject): JSONObject {
        val time = System.currentTimeMillis() / 1000
        val nonce = UUID.randomUUID().toString().replace("-", "").take(16)
        // See class-level doc: sign format is best-effort / needs confirmation.
        val signSource = "time:$time,nonce:$nonce,appSecret:$appSecret"
        val sign = md5Hex(signSource)

        val system = JSONObject()
            .put("ver", "1.0")
            .put("appId", appId)
            .put("sign", sign)
            .put("time", time)
            .put("nonce", nonce)

        return JSONObject()
            .put("system", system)
            .put("id", UUID.randomUUID().toString())
            .put("params", params)
    }

    private fun call(method: String, params: JSONObject): JSONObject {
        val body = buildEnvelope(params).toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
            .url("https://$host/openapi/$method")
            .post(body)
            .build()
        client.newCall(request).execute().use { resp ->
            val text = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                throw ImouApiException("HTTP ${resp.code} calling $method: $text")
            }
            val json = JSONObject(text)
            val result = json.optJSONObject("result")
            val code = result?.optString("code") ?: json.optString("code", "")
            if (code.isNotEmpty() && code != "0") {
                throw ImouApiException("Imou API error ($method): code=$code body=$text")
            }
            return json
        }
    }

    /** Logs in (obtains an accessToken) using the App Id / App Secret entered by the user in-app. */
    fun login(): Boolean {
        val json = call("accessToken", JSONObject())
        val result = json.optJSONObject("result") ?: json
        val data = result.optJSONObject("data")
        val token = data?.optString("accessToken")
        accessToken = token
        return !token.isNullOrEmpty()
    }

    /** Returns the raw device list JSON as documented by deviceBaseList. Parsing into ImouDevice is left to the caller/UI layer. */
    fun listDevices(): JSONObject {
        check(accessToken != null) { "Call login() first" }
        val params = JSONObject().put("token", accessToken).put("pageNo", 1).put("pageSize", 50)
        return call("deviceBaseList", params)
    }
}

class ImouApiException(message: String) : Exception(message)
