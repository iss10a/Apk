package com.imou.audiocontroller.audio

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder

/**
 * Captures mono 16-bit PCM from the device microphone using the standard
 * Android AudioRecord API. Used for the "Test Talk with mic" button. Genuine
 * Android API, no Imou-specific assumptions.
 */
class MicCapture(private val sampleRateHz: Int = 16000) {
    private var recorder: AudioRecord? = null
    @Volatile private var recording = false

    @SuppressLint("MissingPermission")
    fun start(onChunk: (ByteArray) -> Unit) {
        val minBuf = AudioRecord.getMinBufferSize(
            sampleRateHz, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        recorder = AudioRecord(
            MediaRecorder.AudioSource.MIC, sampleRateHz,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, minBuf * 2
        )
        recorder?.startRecording()
        recording = true
        Thread {
            val buf = ByteArray(minBuf)
            while (recording) {
                val n = recorder?.read(buf, 0, buf.size) ?: -1
                if (n > 0) onChunk(buf.copyOf(n))
            }
        }.start()
    }

    fun stop() {
        recording = false
        recorder?.stop()
        recorder?.release()
        recorder = null
    }
}
