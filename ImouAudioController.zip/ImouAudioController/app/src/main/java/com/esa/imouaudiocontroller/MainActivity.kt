package com.esa.imouaudiocontroller

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.CreationExtras
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navigate
import com.esa.imouaudiocontroller.audio.AudioFileController
import com.esa.imouaudiocontroller.data.ImouRepository
import com.esa.imouaudiocontroller.data.ImouRepositoryImpl
import com.esa.imouaudiocontroller.data.model.LoginState
import com.esa.imouaudiocontroller.ui.navigation.Destination
import com.esa.imouaudiocontroller.ui.screens.CameraControlScreen
import com.esa.imouaudiocontroller.ui.screens.CameraListScreen
import com.esa.imouaudiocontroller.ui.screens.LoginScreen
import com.esa.imouaudiocontroller.ui.screens.SdkStatusScreen
import com.esa.imouaudiocontroller.ui.theme.ImouAudioControllerTheme
import com.esa.imouaudiocontroller.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {

    private lateinit var viewModel: MainViewModel

    private val pickAudioLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(
                uri,
                android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            val name = queryDisplayName(uri) ?: "audio"
            viewModel.onAudioFilePicked(uri, name)
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && nameIndex >= 0) {
                return cursor.getString(nameIndex)
            }
        }
        return null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // بدون مكتبة DI — حاويات يدوية بسيطة كما طُلب (لا مكتبات إضافية بدون حاجة).
        val repository: ImouRepository = ImouRepositoryImpl()
        val audioController = AudioFileController(applicationContext)

        val factory = object : ViewModelProvider.Factory {
            override fun <T : androidx.lifecycle.ViewModel> create(
                modelClass: Class<T>,
                extras: CreationExtras
            ): T {
                @Suppress("UNCHECKED_CAST")
                return MainViewModel(repository, audioController) as T
            }
        }
        viewModel = ViewModelProvider(this, factory)[MainViewModel::class.java]

        setContent {
            ImouAudioControllerTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppNavHost(
                        viewModel = viewModel,
                        onPickAudioClick = {
                            pickAudioLauncher.launch(
                                arrayOf("audio/mpeg", "audio/mp4", "audio/x-wav", "audio/wav", "audio/aac", "audio/*")
                            )
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun AppNavHost(
    viewModel: MainViewModel,
    onPickAudioClick: () -> Unit,
    navController: NavHostController = rememberNavController()
) {
    val loginState by viewModel.loginState.collectAsState()
    val cameras by viewModel.cameras.collectAsState()
    val selectedCamera by viewModel.selectedCamera.collectAsState()
    val playbackState by viewModel.playbackState.collectAsState()
    val currentFile by viewModel.currentFile.collectAsState()
    val loopEnabled by viewModel.loopEnabled.collectAsState()
    val sdkStatus by viewModel.sdkStatus.collectAsState()

    // التنقل بعد نجاح الدخول يجب أن يراقب التغيّر الفعلي في الحالة (غير متزامن)
    // وليس التحقق المباشر بعد استدعاء login() — لأن login() يُنفَّذ داخل coroutine
    // ولن تكون الحالة قد تحدّثت بعد بشكل متزامن عند سطر الاستدعاء نفسه.
    LaunchedEffect(loginState) {
        if (loginState is LoginState.Connected) {
            viewModel.loadCameras()
            navController.navigate(Destination.CameraList.route) {
                popUpTo(Destination.Login.route) { inclusive = true }
            }
        }
    }

    NavHost(navController = navController, startDestination = Destination.Login.route) {

        composable(Destination.Login.route) {
            LoginScreen(
                loginState = loginState,
                onLoginClick = { user, pass ->
                    viewModel.login(user, pass)
                }
            )
        }

        composable(Destination.CameraList.route) {
            CameraListScreen(
                cameras = cameras,
                onCameraClick = { camera ->
                    viewModel.selectCamera(camera)
                    navController.navigate(Destination.CameraControl.route)
                }
            )
        }

        composable(Destination.CameraControl.route) {
            CameraControlScreen(
                camera = selectedCamera,
                playbackState = playbackState,
                currentFile = currentFile,
                loopEnabled = loopEnabled,
                talkCapability = sdkStatus.talkCapability,
                onPickAudioClick = onPickAudioClick,
                onPlay = viewModel::playLocal,
                onPause = viewModel::pauseLocal,
                onStop = viewModel::stopLocal,
                onLoopChange = viewModel::setLoop,
                onMusicVolumeChange = viewModel::setMusicVolume,
                onPlayToCameraClick = viewModel::playToCamera
            )
        }

        composable(Destination.SdkStatus.route) {
            SdkStatusScreen(status = sdkStatus)
        }
    }
}
