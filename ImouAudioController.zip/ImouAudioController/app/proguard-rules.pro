# PoC build: minification disabled in release build type, so no rules required yet.
