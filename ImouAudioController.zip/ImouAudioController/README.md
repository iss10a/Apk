# Imou Audio Controller

تطبيق Android (Kotlin + Jetpack Compose) لربط حساب Imou وعرض كاميرا Imou (الموديل المستهدف حاليًا: `IPC-S41FE-7E4F`) وإرسال ملف صوتي من الهاتف إلى سماعة الكاميرا عبر قناة Audio Talk **الرسمية**، إن كان ذلك مدعومًا فعليًا من SDK.

## ⚠️ حالة المشروع الحالية

هذا **هيكل مشروع (skeleton)** وليس تطبيقًا كاملًا. لم يُدمج بعد Imou OpenSDK الرسمي.

- ✅ تسجيل دخول/قائمة كاميرات/معاينة مباشرة: الواجهات جاهزة (`ImouRepository`)، لكن التنفيذ الفعلي (`ImouRepositoryImpl`) لا يزال TODO حتى يُفحص `LCOpenSDK.aar` الرسمي.
- ✅ اختيار وتشغيل ملف صوتي محليًا (MP3/M4A/WAV/AAC) عبر `MediaPlayer`: **مُنفَّذ فعليًا ويعمل** بشكل مستقل عن Imou SDK.
- ❌ إرسال الصوت الفعلي إلى سماعة الكاميرا عبر قناة Talk: **غير مؤكد وغير مُفعَّل**. زر "إرسال إلى الكاميرا" في الواجهة معطّل دائمًا حتى تُعاد قيمة `SUPPORTED` من `checkExternalAudioInjectionCapability()`، وهذه القيمة حاليًا `UNVERIFIED` بشكل ثابت ومتعمّد.

السبب: التوثيق العلني لـ Imou OpenSDK (Android) يوثّق تدفق تخاطب (`LCOpenSDK_Talk.playTalk(...)`) مصمَّمًا حول التقاط صوت من ميكروفون الهاتف مباشرة أثناء المعاينة الحية. لم يظهر في أي مصدر رسمي علني وصول إلى دالة تقبل حقن بيانات PCM من مصدر خارجي (ملف) بدل الميكروفون. هذه النقطة تحتاج فحصًا مباشرًا لملف الـ SDK الحقيقي وتوثيقه الكامل.

## المتطلبات

- Android Studio (Jellyfish أو أحدث)
- JDK 17
- حساب مطوّر على [open.imoulife.com](https://open.imoulife.com) (Imou Open Platform)

## إضافة Imou SDK الرسمي لاحقًا

1. نزّل `LCOpenSDK.aar` بعد تسجيل حساب مطوّر.
2. ضعه في `app/libs/LCOpenSDK.aar`.
3. فعّل هذا السطر في `app/build.gradle.kts`:
   ```kotlin
   implementation(files("libs/LCOpenSDK.aar"))
   ```
4. نفّذ الدوال الفعلية داخل `ImouRepositoryImpl.kt` بدلًا من أسطر `TODO(SDK-PENDING)`.
5. لا تفعّل زر "إرسال إلى الكاميرا" (`playToCamera`) إلا بعد أن يعيد `checkExternalAudioInjectionCapability()` القيمة `SUPPORTED` فعليًا بناءً على واجهات SDK الحقيقية.

## أين أضع بيانات الاعتماد (Credentials)

- انسخ `local.properties.example` إلى `local.properties` (هذا الملف مُستثنى في `.gitignore` ولا يُرفع أبدًا).
- ضع فيه `IMOU_APP_ID` و `IMOU_APP_SECRET` للتطوير المحلي فقط.
- **لا تضع الأسرار داخل الكود ولا داخل GitHub مطلقًا.** توصية Imou نفسها أيضًا: عمليات الحساب/الربط/الإدارة يجب أن تمر عبر backend خاص بك، وليس مباشرة من التطبيق.
- في Codemagic، تُمرَّر هذه القيم كمتغيرات بيئة (Environment variables) في إعدادات التطبيق على codemagic.io، وليس داخل `codemagic.yaml` نفسه.

## ⚠️ ملاحظة مهمة عن Gradle Wrapper

المشروع يحتوي `gradlew` و `gradlew.bat` (سكربتات تشغيل عادية)، لكنه **لا يحتوي** على `gradle/wrapper/gradle-wrapper.jar` (ملف ثنائي مُصرَّف). السبب: هذا الملف الثنائي لم يُنشأ من مصدر يمكن التحقق منه هنا (لا يوجد اتصال إنترنت في بيئة التحضير لتنزيله من `services.gradle.org`، ولا مترجم Java متاح لبنائه من الصفر). تفضيل عدم تضمين ملف ثنائي لم أستطع توليده والتحقق منه فعليًا، على تضمين ملف قد لا يعمل.

طريقتان لحل هذا قبل البناء:

1. **الأسهل — Android Studio**: افتح المشروع في Android Studio مرة واحدة، سيلاحظ غياب الـwrapper jar ويعرض إشعارًا لإعادة توليده تلقائيًا (أو نفّذ من Terminal داخل المشروع: `gradle wrapper --gradle-version 8.7` إذا كان لديك Gradle مثبّت محليًا).
2. **Codemagic**: `codemagic.yaml` المرفق يتعامل مع هذا تلقائيًا — يحتوي خطوة تستخدم نسخة Gradle المثبّتة مسبقًا على صور Codemagic لتوليد `gradle-wrapper.jar` بنفس إصدار Gradle المحدد (8.7) قبل تنفيذ `./gradlew assembleDebug`، فلا حاجة لأي تدخل يدوي هناك.

## البناء محليًا

```bash
gradle wrapper --gradle-version 8.7   # مرة واحدة فقط، لتوليد gradle-wrapper.jar
./gradlew assembleDebug
```
سينتج APK في: `app/build/outputs/apk/debug/app-debug.apk`

## البناء عبر Codemagic

ملف `codemagic.yaml` **منفصل عن الـZIP** كما طُلب. ارفع محتوى الـZIP إلى مستودع GitHub، ثم في codemagic.io أضف المشروع واستبدل/أضف ملف `codemagic.yaml` هذا في جذر المستودع (أو الصقه في إعدادات الـYAML من واجهة Codemagic). ينتج Workflow اسمه `android-debug-build` ملف **Debug APK** فقط حاليًا (Release يحتاج Keystore لم يُضف بعد).

مسار الـAPK الناتج فعليًا يطابق ما هو محدد في `artifacts:` داخل codemagic.yaml: `app/build/outputs/apk/debug/app-debug.apk`.

## تثبيت APK

```bash
adb install app-debug.apk
```
أو انقل الملف يدويًا إلى الهاتف وفعّل "السماح بالتثبيت من مصادر غير معروفة".

## المشاكل المعروفة / القيود الحالية

- تسجيل الدخول، قائمة الكاميرات، والمعاينة المباشرة **غير مفعّلة فعليًا** (تعيد دائمًا فشلًا واضحًا `NotImplementedError` وليس بيانات وهمية).
- ميزة إرسال الصوت للكاميرا **غير مؤكدة الجدوى** حتى فحص SDK الرسمي — راجع قسم "حالة المشروع" أعلاه.
- لا يوجد توقيع Release بعد (Codemagic ينتج Debug APK فقط حاليًا).
- لم تُضف بعد أي مكتبة فك ترميز صوت (decoder) لتحويل الملفات إلى PCM لأن هذا مرهون بمعرفة الصيغة/معدل العينة الذي يطلبه SDK فعليًا.
- `gradle-wrapper.jar` غير مضمَّن (انظر القسم أعلاه) — يُولَّد تلقائيًا في Codemagic، أو يدويًا مرة واحدة محليًا/في Android Studio.
- لم يُنفَّذ بناء Gradle/Kotlin فعلي أثناء تحضير هذا المشروع (لا شبكة إنترنت ولا Android SDK/مترجم Kotlin متاحين في بيئة التحضير). تم بدلًا من ذلك فحص يدوي شامل: تطابق أسماء الحزم مع مسارات الملفات، تطابق كل `R.string.*` المستخدم مع `strings.xml`، تطابق كل استيراد داخلي مع تعريف فعلي، توازن الأقواس/علامات الاقتباس في كل ملف Kotlin، والتحقق من توافق إصدارات AGP 8.5.2 / Kotlin 1.9.24 / Compose Compiler 1.5.14 / Gradle 8.7 من التوثيق الرسمي لـ Google. هذا لا يغني عن بناء Gradle حقيقي — أول Build فعلي سيحدث في Codemagic أو على جهازك.
