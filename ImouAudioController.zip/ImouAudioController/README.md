# Imou Audio Controller

Android app targeting the **IPC-S41FE-7E4F** camera: log in with an Imou
Open Platform account, list devices, watch a real live stream, and attempt
to send a picked WAV/MP3/M4A file (or the mic) to the camera's speaker via
its Talk channel.

## What is genuinely implemented and testable today

- **Login (real, official API, signature verified):** `ImouOpenApiClient`
  calls the documented `accessToken` endpoint
  (`openapi-sg.easy4ip.com`), signing requests with the official algorithm
  from https://open.imou.com/document/pages/c20750/. Verified against the
  official test vector.
- **Device list:** `deviceBaseList` + `deviceBaseDetailList`, matching the
  documented request/response shape (open.imoulife.com/book/http/device/manage/...).
  Flags the IPC-S41FE-7E4F if present.
- **Live View — NEW, real, no closed SDK:** `ImouOpenApiClient.bindDeviceLive()`
  calls the documented `bindDeviceLive` OpenAPI method
  (open.imoulife.com/book/http/device/live/bindDeviceLive.html), which returns
  a plain HLS `.m3u8` URL for the device/channel. `LiveViewScreen.kt` plays
  that URL with standard AndroidX Media3 ExoPlayer. This needed **zero**
  LCOpenSDK/native binary — just the same signed-REST pattern already used
  for login/device-list, plus a standard media player. HD/SD toggle and Stop
  are wired up. This is a real, watchable stream on a real device today.
- **Audio file decoding:** `AudioFileDecoder` uses Android's standard
  `MediaExtractor`/`MediaCodec` to turn WAV/MP3/M4A into raw 16-bit PCM.
  Generic Android API, no Imou dependency.
- **Codec conversion:** `AudioCodec` does mono-downmix, linear resampling,
  a from-spec ITU-T G.711 A-law encoder, AAC/ADTS encoding, and (new) a
  standard WAV writer.
- **Mic capture / "Test Talk with mic" — now a real, verifiable test:**
  `MicCapture` records real mic audio via `AudioRecord`. The button now
  records, writes a real playable WAV file, and gives you a **▶️ Play**
  button so you can actually listen back and confirm the mic path works.
  It intentionally does **not** claim this reaches the camera (see below).
- **`FileSinkTalkTransport`**: writes the final encoded audio (post decode →
  PCM → A-law) to a local file so the entire non-camera part of the pipeline
  is provably exercised end-to-end. The UI explicitly labels this as *not*
  reaching the camera — no fake "Sending..." success state.
- **Loop / Stop**: the "Play → إرسال للكاميرا" button now runs as a
  cancellable coroutine; the Loop checkbox repeats the pipeline until you
  press **⏹ Stop**, which cancels immediately (no delayed/half state).

## What is NOT implemented, and exactly why (re-verified this session)

**Sending a picked audio file's bytes into the camera's speaker is not
possible with any officially documented API available to me.** This was
independently re-checked (not just re-quoting your prior research) against
Imou's own published Android integration guide:

- `LCOpenSDK_Talk`'s entire documented surface is
  `setListener(...)`, `playTalk(ParamTalk)`, `stopTalk()`. `ParamTalk` only
  carries `accessToken`, `deviceID`, `channel`, `psk`, `playToken` — **no
  audio field**. There is no `sendAudio`/`pushAudioFrame`/
  `onRequestAudioData` anywhere in the documented API. The SDK opens the
  *phone's own* microphone internally, inside the closed `.aar`.
- Because that `.aar` isn't public and this sandbox has no way to fetch it,
  it isn't bundled in this project at all — Live View was instead built on
  the documented `bindDeviceLive` REST method (see above), which needs no
  closed binary.

**The one real, citable alternative found** (not invented): Dahua's
separate general-purpose **NetSDK** (used by Dahua/Lechange NVR client
software — a different SDK from the Imou cloud OpenSDK) documents a real
local-network audio-push API: `CLIENT_StartTalkEx` → `CLIENT_TalkSendData`
→ `CLIENT_StopTalkEx` (Dahua "NetSDK Programming Manual", §2.7 "Voice
Talk"). A third party has also published an open-source (MIT, Go)
reimplementation of the same wire protocol without that SDK — see
**AlexxIT/go2rtc pull request #2431**, "Add native Dahua two-way audio
backchannel (TCP/37777)" — confirmed working by two independent users on
real Dahua-branded/OEM PoE cameras.

This is documented in detail, with the caveats spelled out plainly, in
`ImouTalkTransport.kt` (`DahuaLocalTalkTransport` class doc). In short:

- It needs **local LAN** access to the camera on TCP port 37777, with the
  device's "Private Protocol Authentication Mode" possibly set to
  "Compatible" — a different, non-cloud path from the Open Platform
  account this app otherwise uses.
- It is **not verified** whether a consumer Imou Wi-Fi camera
  (IPC-S41FE-7E4F) exposes this at all — every device confirmed working in
  that PR thread is a Dahua-branded/OEM PoE camera, a different product
  line. Check with `nmap -p 37777 <camera-ip>` on your own network first.
- I only have that PR's **description** in this environment, not its actual
  Go source files, so I could not port the exact DHAV byte framing without
  guessing — which is exactly the "invented protocol" you told me not to
  write. `DahuaLocalTalkTransport` opens a real TCP socket to port 37777
  and then throws a clearly labeled `NotImplementedError` at the point
  where the real framing would go.

**To finish this specific piece**, either:
1. Confirm port 37777 is actually reachable/usable on your camera, then get
   me the real source of `stream-z:feat/dahua-backchannel` (package
   `pkg/dahua`) in `AlexxIT/go2rtc`, so the exact DHAV framing can be ported
   from verified bytes instead of a placeholder; or
2. Get the real Dahua Android **NetSDK** `.aar` (a different, separate SDK
   from LCOpenSDK) from Dahua/your camera's OEM support channel, and I can
   wire `CLIENT_StartTalkEx`/`CLIENT_TalkSendData` against its actual
   exposed Kotlin/Java wrapper class names (which I cannot guess — they
   vary per SDK release).

The rest of the app (login, device list, Live View, file picker, mic test,
PCM/codec pipeline, UI, Loop/Stop) does not need to change for either path.

## Build status (from this environment)

I could not actually run Gradle here: this sandbox has no general internet
access, and Gradle needs to download the wrapper, the Android Gradle
Plugin, and all dependencies (including the newly added Media3 libraries)
from Google/Maven. **You must run the build on Codemagic (or Android
Studio) to get a real PASS/FAIL.**

| Item | Status |
|---|---|
| BUILD TEST | NOT RUN HERE (no internet in this sandbox) — run on Codemagic |
| CODEMAGIC YAML | Valid YAML; unzips a root-level zip or finds a nested project dir automatically; `max_build_duration` bumped to 45 min for the added Media3 deps |
| IMOU LOGIN | IMPLEMENTED, signature verified against official test vector |
| DEVICE LIST | IMPLEMENTED, call shape correct against official docs |
| LIVE VIEW | **IMPLEMENTED — real HLS via `bindDeviceLive`, played with Media3 ExoPlayer. Needs testing on your real device/network.** |
| MIC TEST | IMPLEMENTED — real recording + real local playback for verification. Does NOT reach the camera (see above). |
| AUDIO FILE → CAMERA SPEAKER | **NOT POSSIBLE with any officially documented API found.** Local pipeline (decode → PCM → codec) is fully implemented and provably correct; the last mile (camera transport) is not, for the reasons above. |
| Loop / Stop | IMPLEMENTED as a cancellable coroutine job |

## Running the build on Codemagic

1. Push this project's contents (not the zip) to a Git repository, or let
   Codemagic unzip it at checkout — either way `codemagic.yaml` must end up
   at the **repository root**.
2. Add the app in Codemagic — it should detect `codemagic.yaml` and the
   workflow `imou-audio-controller-debug`.
3. The first script step runs `gradle wrapper --gradle-version 8.7` because
   the wrapper jar itself is intentionally **not committed**. If your build
   image lacks a system `gradle`, swap that step for whatever your chosen
   image documents.
4. On success, the APK is under `app/build/outputs/apk/debug/`; the
   workflow also `find`s every `.apk` produced, so you don't have to trust
   an assumed path.

## What is safe to commit

No AppSecret, AppId, password, access token, or keystore is present
anywhere in this project. Login credentials are entered in the running
app and kept only in memory.

## Testing checklist for the real camera

- [ ] Login with real App Id/Secret
- [ ] Device list shows the IPC-S41FE-7E4F
- [ ] Live View: tap "بث مباشر" → HD and SD both play, Stop actually stops
- [ ] Mic test: record, then tap ▶️ and confirm you hear yourself
- [ ] File pipeline: pick a WAV/MP3/M4A, confirm `talk_output.alaw` is
      written to the app's cache dir with plausible size (proves decode +
      codec conversion ran) — this will NOT play from the camera speaker
- [ ] (Optional, if pursuing the Dahua-local path) `nmap -p 37777 <camera-ip>`
      from the same LAN, to see if that avenue is even reachable on this
      camera before investing more time in it
