# Imou Audio Controller (Proof of Concept)

Android app targeting the **IPC-S41FE-7E4F** camera. Goal for this PoC:
pick a WAV/MP3/M4A file (or test with the mic) → decode to PCM → encode to
a codec the camera speaker accepts → send to the camera's Talk channel.

## What is genuinely implemented and testable today

- **Login (real, official API, signature verified):** `ImouOpenApiClient`
  calls the documented Imou Open Platform `accessToken` endpoint
  (`openapi-sg.easy4ip.com`), signing requests with the official algorithm
  from https://open.imou.com/document/pages/c20750/ (`sign =
  Base64(HMAC-SHA256("time:{time},nonce:{nonce},appSecret:{appSecret}",
  key = LowerHex(SHA-256(appSecret))))`). This was checked against the
  official test vector and matches exactly. You enter your own App
  Id/App Secret in the app — nothing is hardcoded or committed.
- **Device list:** calls `deviceBaseList` with the signed envelope above.
  The exact required *parameters* for this specific method are not
  independently verified by me — if you see `OP1002 Parameter missing`,
  please paste the corresponding open.imou.com doc page (as you did for
  the signature) so this gets fixed against the real spec rather than
  guessed again.
- **Device list UI:** parses the documented `deviceBaseList` response and
  flags the IPC-S41FE-7E4F if present on the account.
- **Audio file decoding:** `AudioFileDecoder` uses Android's standard
  `MediaExtractor`/`MediaCodec` to turn WAV/MP3/M4A into raw 16-bit PCM.
  Generic Android API, no Imou dependency — testable on any file.
- **Codec conversion:** `AudioCodec` does mono-downmix, linear resampling,
  a from-spec ITU-T G.711 A-law encoder, and AAC/ADTS encoding via
  Android's built-in AAC encoder. Also generic, verifiable, testable.
- **Mic capture** for the "Test Talk with mic" button: standard
  `AudioRecord`.
- **`FileSinkTalkTransport`**: writes the final encoded audio to a local
  file instead of a camera, so you can run the *entire* pipeline
  (pick file → decode → PCM → A-law) on a real device today and inspect
  the output file, with zero unverified protocol code involved.

## What is NOT implemented, and why (per your explicit instruction not to invent an API)

`ImouTalkTransport` / `ImouP2PTalkTransport` opens a real TCP socket to the
camera's documented Talk port (**8086**, per the reference project's
README) but the actual **byte-level framing** of the Imou/Dahua Talk
protocol (DHP2P "type 0" relay, or the LAN "DHHTTP visualtalk.xav" path) is
**not implemented**. It throws a clearly labeled `NotImplementedError`
instead of a fabricated request.

Why: the reference project you linked
(`home-assistant-tools/imou-life`) documents in its README that its own
two-way-talk support is the result of **binary-level reverse engineering**
of Dahua's proprietary protocol, and that this is still described as
*experimental* and *camera-model-dependent*. In this build environment I
could fetch that repository's **README only** — I do not have general
internet access (no `git clone`, and GitHub's individual source-file pages
were not fetchable with the tools available to me here), so I never saw
the actual Python source that performs the byte-level framing. Writing
that framing from guesswork would be exactly the "fake API" you told me
not to build.

**To finish this specific piece**, please share (paste or upload) one or
both of:
- the reference project's Python module that implements the P2P/LAN talk
  send (`frigate_imou_talk_exec.py` and/or its underlying P2P client), and
- `docs/talk-protocol-reverse-engineering.md` and `docs/two-way-audio.md`
  from that repository.

With that source in hand I can port the exact packet/session framing into
`ImouP2PTalkTransport` instead of the current placeholder — the rest of the
app (login, device list, file picker, PCM/codec pipeline, UI) does not need
to change.

Live View was intentionally left out of this PoC per your instruction, to
avoid delaying the audio path. `ImouDevice`/`DeviceListScreen` are already
structured so a Live View screen can be added later without rework.

## Build status (from this environment)

I could not actually run Gradle here: this sandbox has no general internet
access, and Gradle needs to download the wrapper, the Android Gradle
Plugin, and all dependencies from Google/Maven. I am not reporting a build
result I did not observe. **You must run the build on Codemagic (or Android
Studio) to get a real PASS/FAIL** — see below.

| Item | Status |
|---|---|
| BUILD TEST | NOT RUN HERE (no internet in this sandbox) — run on Codemagic |
| KOTLIN COMPILATION | NOT RUN HERE |
| GRADLE | NOT RUN HERE |
| CODEMAGIC YAML | Valid YAML (parsed locally with a YAML parser), semantics not verified against a live Codemagic run |
| APK GENERATED | NO (not produced in this environment) |
| APK PATH | Expected `app/build/outputs/apk/debug/app-debug.apk`, but codemagic.yaml also runs `find` to print the real path — do not trust the expected path blindly |
| IMOU LOGIN | IMPLEMENTED (official Open API, signature verified against official test vector) |
| DEVICE LIST | IMPLEMENTED, call shape correct; exact `deviceBaseList` params unverified — send the doc page if you hit `OP1002` |
| LIVE VIEW | NOT INCLUDED (deferred per your request) |
| TWO-WAY TALK / FILE AUDIO → CAMERA SPEAKER | NOT POSSIBLE WITH AVAILABLE INFORMATION in this environment — needs the reference project's actual source (see above) |
| Audio decode + PCM + codec pipeline | IMPLEMENTED, runnable end-to-end into a local file today |

## Running the build on Codemagic

1. Push this project's contents (not the zip) to a Git repository, or let
   Codemagic unzip `ImouAudioController.zip` at checkout if you keep
   distributing it zipped — either way `codemagic.yaml` must end up at the
   **repository root** for Codemagic to auto-detect it.
2. In Codemagic, add the app from your repo — it should detect
   `codemagic.yaml` and the workflow `imou-audio-controller-debug`.
3. `codemagic.yaml`'s first step runs `gradle wrapper --gradle-version 8.7`
   because the wrapper jar itself is intentionally **not committed** (a
   binary file I cannot verify from this sandbox). If the build image
   doesn't have a system `gradle`, replace that one step with whatever
   Gradle-install step your chosen Codemagic image documents — nothing
   else in the project depends on how the wrapper gets there.
4. No `instance_type` is set, so Codemagic uses the workflow's default
   machine on your current plan.
5. On success, the APK is under `app/build/outputs/apk/debug/`; the
   workflow also runs `find` over the build directory and prints every
   `.apk` it finds, so you don't have to trust the assumed path.

## What is safe to commit

No AppSecret, AppId, password, access token, or keystore is present
anywhere in this project. Login credentials are entered in the running
app and kept only in memory.
