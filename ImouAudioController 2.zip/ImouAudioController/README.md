# Imou Audio Controller

تطبيق Android (Kotlin + Jetpack Compose) لربط حساب Imou وعرض كاميرا Imou (الموديل المستهدف حاليًا: `IPC-S41FE-7E4F`) وإرسال ملف صوتي من الهاتف إلى سماعة الكاميرا عبر قناة Audio Talk **الرسمية**، إن كان ذلك مدعومًا فعليًا من SDK.

## ⚠️ حالة المشروع الحالية

هذا **هيكل مشروع (skeleton)** وليس تطبيقًا كاملًا. لم يُدمج بعد Imou OpenSDK الرسمي.

- ✅ تسجيل دخول/قائمة كاميرات/معاينة مباشرة: الواجهات جاهزة (`ImouRepository`)، لكن التنفيذ الفعلي (`ImouRepositoryImpl`) لا يزال TODO حتى يُفحص `LCOpenSDK.aar` الرسمي.
- ✅ اختيار وتشغيل ملف صوتي محليًا (MP3/M4A/WAV/AAC) عبر `MediaPlayer`: **مُنفَّذ فعليًا ويعمل** بشكل مستقل عن Imou SDK.
- ❌ إرسال الصوت الفعلي إلى سماعة الكاميرا عبر قناة Talk: **غير مؤكد وغير مُفعَّل**. زر "إرسال إلى الكاميرا" في الواجهة معطّل دائمًا حتى تُعاد قيمة `SUPPORTED` من `checkExternalAudioInjectionCapability()`، وهذه القيمة حاليًا `UNVERIFIED` بشكل ثابت ومتعمّد.

السبب: التوثيق العلني لـ Imou OpenSDK (Android) يوثّق تدفق تخاطب (`LCOpenSDK_Talk.playTalk(...)`) مصمَّمًا حول التقاط صوت من ميكروفون الهاتف مباشرة أثناء المعاينة الحية. لم يظهر في أي مصدر رسمي علني وصول إلى دالة تقبل حقن بيانات PCM من مصدر خارجي (ملف) بدل الميكروفون. هذه النقطة تحتاج فحصًا مباشرًا لملف الـ SDK الحقيقي وتوثيقه الكامل.

## المتطلبات

- Android Studio (Jellyfish أو أحدث)
- JDK 17
- حساب مطوّر على [open.imoulife.com](https://open.imoulife.com) (Imou Open Platform)

## إضافة Imou SDK الرسمي لاحقًا

1. نزّل `LCOpenSDK.aar` بعد تسجيل حساب مطوّر.
2. ضعه في `app/libs/LCOpenSDK.aar`.
3. فعّل هذا السطر في `app/build.gradle.kts`:
   ```kotlin
   implementation(files("libs/LCOpenSDK.aar"))
   ```
4. نفّذ الدوال الفعلية داخل `ImouRepositoryImpl.kt` بدلًا من أسطر `TODO(SDK-PENDING)`.
5. لا تفعّل زر "إرسال إلى الكاميرا" (`playToCamera`) إلا بعد أن يعيد `checkExternalAudioInjectionCapability()` القيمة `SUPPORTED` فعليًا بناءً على واجهات SDK الحقيقية.

## أين أضع بيانات الاعتماد (Credentials)

- انسخ `local.properties.example` إلى `local.properties` (هذا الملف مُستثنى في `.gitignore` ولا يُرفع أبدًا).
- ضع فيه `IMOU_APP_ID` و `IMOU_APP_SECRET` للتطوير المحلي فقط.
- **لا تضع الأسرار داخل الكود ولا داخل GitHub مطلقًا.** توصية Imou نفسها أيضًا: عمليات الحساب/الربط/الإدارة يجب أن تمر عبر backend خاص بك، وليس مباشرة من التطبيق.
- في Codemagic، تُمرَّر هذه القيم كمتغيرات بيئة (Environment variables) في إعدادات التطبيق على codemagic.io، وليس داخل `codemagic.yaml` نفسه.

## البناء محليًا

```bash
./gradlew assembleDebug
```
سينتج APK في: `app/build/outputs/apk/debug/app-debug.apk`

## البناء عبر Codemagic

المشروع يحتوي `codemagic.yaml` جاهزًا لإنتاج **Debug APK** (التوقيع Release يحتاج إعداد Keystore إضافي لم يُضف بعد). ارفع المشروع إلى GitHub، ثم أضفه في [codemagic.io/apps](https://codemagic.io/apps) واربطه بمستودعك — سيلتقط `codemagic.yaml` تلقائيًا.

## تثبيت APK

```bash
adb install app-debug.apk
```
أو انقل الملف يدويًا إلى الهاتف وفعّل "السماح بالتثبيت من مصادر غير معروفة".

## المشاكل المعروفة / القيود الحالية

- تسجيل الدخول، قائمة الكاميرات، والمعاينة المباشرة **غير مفعّلة فعليًا** (تعيد دائمًا فشلًا واضحًا `NotImplementedError` وليس بيانات وهمية).
- ميزة إرسال الصوت للكاميرا **غير مؤكدة الجدوى** حتى فحص SDK الرسمي — راجع قسم "حالة المشروع" أعلاه.
- لا يوجد توقيع Release بعد (Codemagic ينتج Debug APK فقط حاليًا).
- لم تُضف بعد أي مكتبة فك ترميز صوت (decoder) لتحويل الملفات إلى PCM لأن هذا مرهون بمعرفة الصيغة/معدل العينة الذي يطلبه SDK فعليًا.
