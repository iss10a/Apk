package com.esa.imouaudiocontroller.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.esa.imouaudiocontroller.R
import com.esa.imouaudiocontroller.audio.AudioFileMeta
import com.esa.imouaudiocontroller.audio.PlaybackState
import com.esa.imouaudiocontroller.data.model.CameraInfo
import com.esa.imouaudiocontroller.data.model.ExternalAudioInjectionCapability

@Composable
fun CameraControlScreen(
    camera: CameraInfo?,
    playbackState: PlaybackState,
    currentFile: AudioFileMeta?,
    loopEnabled: Boolean,
    talkCapability: ExternalAudioInjectionCapability,
    onPickAudioClick: () -> Unit,
    onPlay: () -> Unit,
    onPause: () -> Unit,
    onStop: () -> Unit,
    onLoopChange: (Boolean) -> Unit,
    onMusicVolumeChange: (Float) -> Unit,
    onPlayToCameraClick: () -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = camera?.name ?: "لم يتم اختيار كاميرا",
            style = MaterialTheme.typography.headlineSmall
        )
        Spacer(Modifier.height(8.dp))
        Text(stringResource(R.string.live_preview) + " — (يتطلب SDK رسمي، غير مفعّل بعد)")

        Spacer(Modifier.height(24.dp))
        Text(text = currentFile?.displayName ?: "لم يُختر ملف صوتي بعد")

        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onPickAudioClick) {
                Text(stringResource(R.string.choose_audio))
            }
        }

        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onPlay, enabled = currentFile != null) {
                Text(stringResource(R.string.play))
            }
            Button(onClick = onPause, enabled = playbackState == PlaybackState.PLAYING) {
                Text(stringResource(R.string.pause))
            }
            Button(onClick = onStop, enabled = currentFile != null) {
                Text(stringResource(R.string.stop))
            }
        }

        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Checkbox(checked = loopEnabled, onCheckedChange = onLoopChange)
            Text(stringResource(R.string.loop))
        }

        Spacer(Modifier.height(16.dp))
        Text(stringResource(R.string.music_volume))
        var musicVolume by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(1f) }
        Slider(
            value = musicVolume,
            onValueChange = {
                musicVolume = it
                onMusicVolumeChange(it)
            }
        )

        Spacer(Modifier.height(24.dp))
        Divider()
        Spacer(Modifier.height(16.dp))

        val sendEnabled = talkCapability == ExternalAudioInjectionCapability.SUPPORTED
        Button(
            onClick = onPlayToCameraClick,
            enabled = sendEnabled,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(stringResource(R.string.play_to_camera))
        }

        if (!sendEnabled) {
            Spacer(Modifier.height(8.dp))
            Text(
                text = stringResource(R.string.feature_pending_sdk),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error
            )
        }
    }
}
