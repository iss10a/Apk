package com.esa.imouaudiocontroller.audio

import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class PlaybackState { IDLE, PREPARING, PLAYING, PAUSED, STOPPED, ERROR }

data class AudioFileMeta(
    val uri: Uri,
    val displayName: String,
    val durationMs: Int
)

/**
 * تحكم حقيقي وفعلي بتشغيل ملف صوتي محلي (MP3/M4A/WAV/AAC) عبر MediaPlayer.
 *
 * هذا الجزء لا علاقة له بـ Imou SDK إطلاقًا — إنه فقط تشغيل محلي على سماعة
 * الهاتف لغرض المعاينة/الاختيار قبل (أو بمعزل عن) أي إرسال للكاميرا.
 * الربط بينه وبين قناة Talk الفعلية يتم لاحقًا فقط بعد تأكيد الدعم في SDK.
 */
class AudioFileController(private val context: Context) {

    private var mediaPlayer: MediaPlayer? = null

    private val _playbackState = MutableStateFlow(PlaybackState.IDLE)
    val playbackState: StateFlow<PlaybackState> = _playbackState.asStateFlow()

    private val _currentFile = MutableStateFlow<AudioFileMeta?>(null)
    val currentFile: StateFlow<AudioFileMeta?> = _currentFile.asStateFlow()

    private val _loopEnabled = MutableStateFlow(false)
    val loopEnabled: StateFlow<Boolean> = _loopEnabled.asStateFlow()

    fun setLoop(enabled: Boolean) {
        _loopEnabled.value = enabled
        mediaPlayer?.isLooping = enabled
    }

    fun load(uri: Uri, displayName: String) {
        release()
        _playbackState.value = PlaybackState.PREPARING
        try {
            val player = MediaPlayer().apply {
                setDataSource(context, uri)
                isLooping = _loopEnabled.value
                setOnPreparedListener {
                    _currentFile.value = AudioFileMeta(uri, displayName, duration)
                    _playbackState.value = PlaybackState.STOPPED
                }
                setOnCompletionListener {
                    if (!_loopEnabled.value) {
                        _playbackState.value = PlaybackState.STOPPED
                    }
                }
                setOnErrorListener { _, _, _ ->
                    _playbackState.value = PlaybackState.ERROR
                    true
                }
                prepareAsync()
            }
            mediaPlayer = player
        } catch (e: Exception) {
            _playbackState.value = PlaybackState.ERROR
        }
    }

    fun play() {
        mediaPlayer?.let {
            it.start()
            _playbackState.value = PlaybackState.PLAYING
        }
    }

    fun pause() {
        mediaPlayer?.let {
            if (it.isPlaying) {
                it.pause()
                _playbackState.value = PlaybackState.PAUSED
            }
        }
    }

    fun stop() {
        mediaPlayer?.let {
            if (it.isPlaying || _playbackState.value == PlaybackState.PAUSED) {
                it.seekTo(0)
                it.pause()
            }
            _playbackState.value = PlaybackState.STOPPED
        }
    }

    fun seekTo(positionMs: Int) {
        mediaPlayer?.seekTo(positionMs)
    }

    fun currentPositionMs(): Int = mediaPlayer?.currentPosition ?: 0

    fun setVolume(volume: Float) {
        val clamped = volume.coerceIn(0f, 1f)
        mediaPlayer?.setVolume(clamped, clamped)
    }

    fun release() {
        mediaPlayer?.release()
        mediaPlayer = null
    }
}
