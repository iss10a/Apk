package com.esa.imouaudiocontroller

import android.app.Application

/**
 * نقطة البداية العامة للتطبيق.
 * لا تُهيّئ هنا أي SDK وهمي — التهيئة الفعلية لـ Imou OpenSDK تُضاف فقط
 * بعد تأكيد واجهاته من الملف الرسمي LCOpenSDK.aar.
 */
class ImouAudioControllerApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // TODO(SDK-PENDING): تهيئة Imou OpenSDK هنا بعد التأكيد الرسمي، مثال متوقع فقط:
        // LCOpenSDK_Api.getInstance().init(this, BuildConfig.IMOU_APP_ID)
        // لا تُفعَّل هذه السطور قبل التأكد من التوقيع الحقيقي للدوال.
    }
}
