package com.esa.imouaudiocontroller.data.model

enum class ExternalAudioInjectionCapability {
    UNVERIFIED,
    SUPPORTED,
    NOT_SUPPORTED
}

data class SdkStatusSnapshot(
    val sdkConnected: Boolean = false,
    val cameraOnline: OnlineStatus = OnlineStatus.UNKNOWN,
    val talkCapability: ExternalAudioInjectionCapability = ExternalAudioInjectionCapability.UNVERIFIED,
    val audioFileReady: Boolean = false,
    val transmissionState: TransmissionState = TransmissionState.NOT_APPLICABLE
)

enum class TransmissionState { NOT_APPLICABLE, READY, RUNNING, ERROR }
