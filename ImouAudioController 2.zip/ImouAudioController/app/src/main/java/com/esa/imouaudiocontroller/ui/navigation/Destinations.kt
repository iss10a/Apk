package com.esa.imouaudiocontroller.ui.navigation

sealed class Destination(val route: String) {
    data object Login : Destination("login")
    data object CameraList : Destination("camera_list")
    data object CameraControl : Destination("camera_control")
    data object SdkStatus : Destination("sdk_status")
}
