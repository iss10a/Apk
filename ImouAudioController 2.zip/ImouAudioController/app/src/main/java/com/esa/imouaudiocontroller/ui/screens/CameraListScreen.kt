package com.esa.imouaudiocontroller.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.esa.imouaudiocontroller.R
import com.esa.imouaudiocontroller.data.model.CameraInfo
import com.esa.imouaudiocontroller.data.model.OnlineStatus

@Composable
fun CameraListScreen(
    cameras: List<CameraInfo>,
    onCameraClick: (CameraInfo) -> Unit
) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(
            text = stringResource(R.string.camera_list_title),
            style = MaterialTheme.typography.headlineSmall
        )
        Spacer(Modifier.height(12.dp))

        if (cameras.isEmpty()) {
            Text(
                text = "لا توجد كاميرات بعد — هذا متوقع في هذا الهيكل لأن جلب الأجهزة يتطلب Imou SDK رسمي غير مدمج بعد.",
                style = MaterialTheme.typography.bodyMedium
            )
        } else {
            LazyColumn {
                items(cameras) { camera ->
                    CameraRow(camera = camera, onClick = { onCameraClick(camera) })
                    Divider()
                }
            }
        }
    }
}

@Composable
private fun CameraRow(camera: CameraInfo, onClick: () -> Unit) {
    ListItem(
        headlineContent = { androidx.compose.material3.Text(camera.name) },
        supportingContent = {
            val statusRes = when (camera.onlineStatus) {
                OnlineStatus.ONLINE -> R.string.camera_status_online
                OnlineStatus.OFFLINE -> R.string.camera_status_offline
                OnlineStatus.UNKNOWN -> R.string.camera_status_unknown
            }
            androidx.compose.material3.Text(stringResource(statusRes))
        },
        modifier = Modifier.clickable(onClick = onClick)
    )
}
