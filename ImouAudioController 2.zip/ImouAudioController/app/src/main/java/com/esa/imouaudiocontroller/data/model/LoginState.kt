package com.esa.imouaudiocontroller.data.model

sealed interface LoginState {
    data object NotConnected : LoginState
    data object Connecting : LoginState
    data class Connected(val accountLabel: String) : LoginState
    data class Error(val message: String) : LoginState
}
