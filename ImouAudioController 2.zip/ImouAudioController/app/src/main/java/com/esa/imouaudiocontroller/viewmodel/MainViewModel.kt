package com.esa.imouaudiocontroller.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.esa.imouaudiocontroller.audio.AudioFileController
import com.esa.imouaudiocontroller.audio.PlaybackState
import com.esa.imouaudiocontroller.data.ImouRepository
import com.esa.imouaudiocontroller.data.model.CameraInfo
import com.esa.imouaudiocontroller.data.model.ExternalAudioInjectionCapability
import com.esa.imouaudiocontroller.data.model.LoginState
import com.esa.imouaudiocontroller.data.model.SdkStatusSnapshot
import com.esa.imouaudiocontroller.data.model.TransmissionState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MainViewModel(
    private val repository: ImouRepository,
    private val audioController: AudioFileController
) : ViewModel() {

    val loginState: StateFlow<LoginState> = repository.loginState
    val playbackState: StateFlow<PlaybackState> = audioController.playbackState
    val currentFile = audioController.currentFile
    val loopEnabled = audioController.loopEnabled

    private val _cameras = MutableStateFlow<List<CameraInfo>>(emptyList())
    val cameras: StateFlow<List<CameraInfo>> = _cameras.asStateFlow()

    private val _selectedCamera = MutableStateFlow<CameraInfo?>(null)
    val selectedCamera: StateFlow<CameraInfo?> = _selectedCamera.asStateFlow()

    private val _sdkStatus = MutableStateFlow(SdkStatusSnapshot())
    val sdkStatus: StateFlow<SdkStatusSnapshot> = _sdkStatus.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    fun login(username: String, password: String) {
        viewModelScope.launch {
            repository.login(username, password)
                .onFailure { _errorMessage.value = it.message }
        }
    }

    fun loadCameras() {
        viewModelScope.launch {
            repository.fetchCameras()
                .onSuccess { _cameras.value = it }
                .onFailure { _errorMessage.value = it.message }
        }
    }

    fun selectCamera(camera: CameraInfo) {
        _selectedCamera.value = camera
        refreshSdkStatus(camera.deviceId)
    }

    fun refreshSdkStatus(deviceId: String) {
        viewModelScope.launch {
            val capability = repository.checkExternalAudioInjectionCapability(deviceId)
            _sdkStatus.value = _sdkStatus.value.copy(
                talkCapability = capability,
                transmissionState = if (capability == ExternalAudioInjectionCapability.SUPPORTED) {
                    TransmissionState.READY
                } else {
                    TransmissionState.NOT_APPLICABLE
                }
            )
        }
    }

    fun onAudioFilePicked(uri: Uri, displayName: String) {
        audioController.load(uri, displayName)
        _sdkStatus.value = _sdkStatus.value.copy(audioFileReady = true)
    }

    fun playLocal() = audioController.play()
    fun pauseLocal() = audioController.pause()
    fun stopLocal() = audioController.stop()
    fun setLoop(enabled: Boolean) = audioController.setLoop(enabled)
    fun setMusicVolume(volume: Float) = audioController.setVolume(volume)

    /**
     * زر "إرسال إلى الكاميرا". يبقى معطّلًا فعليًا في واجهة المستخدم
     * ما لم تكن talkCapability == SUPPORTED. هذه الدالة موجودة فقط
     * لتوضيح مسار الاستدعاء المستقبلي ولا تنجح أبدًا في الوضع الحالي.
     */
    fun playToCamera() {
        val camera = _selectedCamera.value ?: return
        viewModelScope.launch {
            repository.startTalkWithExternalAudio(camera.deviceId) { null }
                .onFailure { _errorMessage.value = it.message }
        }
    }

    fun clearError() {
        _errorMessage.value = null
    }

    override fun onCleared() {
        super.onCleared()
        audioController.release()
    }
}
