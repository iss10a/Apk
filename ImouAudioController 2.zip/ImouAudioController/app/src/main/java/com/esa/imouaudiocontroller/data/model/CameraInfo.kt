package com.esa.imouaudiocontroller.data.model

enum class OnlineStatus { ONLINE, OFFLINE, UNKNOWN }

data class CameraInfo(
    val deviceId: String,
    val name: String,
    val model: String,
    val onlineStatus: OnlineStatus
)
