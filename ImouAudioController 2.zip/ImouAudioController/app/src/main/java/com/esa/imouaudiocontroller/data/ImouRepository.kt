package com.esa.imouaudiocontroller.data

import com.esa.imouaudiocontroller.data.model.CameraInfo
import com.esa.imouaudiocontroller.data.model.ExternalAudioInjectionCapability
import com.esa.imouaudiocontroller.data.model.LoginState
import kotlinx.coroutines.flow.StateFlow

/**
 * الواجهة التي ستُنفَّذ فعليًا فوق Imou OpenSDK الرسمي.
 * هذا الملف لا يستدعي أي API وهمي — إنه فقط العقد (contract) الذي
 * ستلتزم به [ImouRepositoryImpl] بعد دمج LCOpenSDK.aar الحقيقي.
 */
interface ImouRepository {

    val loginState: StateFlow<LoginState>

    /** تسجيل الدخول إلى حساب Imou. */
    suspend fun login(username: String, password: String): Result<Unit>

    fun logout()

    /** جلب قائمة الكاميرات المرتبطة بحساب المطوّر. */
    suspend fun fetchCameras(): Result<List<CameraInfo>>

    /** بدء المعاينة المباشرة لكاميرا محددة. يعيد معرّف/مقبض المعاينة عند النجاح. */
    suspend fun startLivePreview(deviceId: String): Result<Unit>

    fun stopLivePreview(deviceId: String)

    /**
     * التحقق الفعلي مما إذا كان SDK يدعم حقن صوت خارجي (PCM من ملف)
     * في قناة Talk، بدل الاعتماد على ميكروفون الهاتف.
     *
     * التنفيذ الحالي دائمًا [ExternalAudioInjectionCapability.UNVERIFIED]
     * إلى أن يُفحص LCOpenSDK.aar فعليًا. ممنوع لأي طبقة أعلى أن تفترض
     * SUPPORTED دون أن تمر عبر هذه الدالة.
     */
    suspend fun checkExternalAudioInjectionCapability(deviceId: String): ExternalAudioInjectionCapability

    /**
     * بدء إرسال صوت (PCM محوَّل من الملف) إلى قناة Talk الخاصة بالكاميرا.
     *
     * ⚠️ لا تُنفَّذ هذه الدالة إطلاقًا قبل أن يعيد
     * [checkExternalAudioInjectionCapability] القيمة SUPPORTED.
     * التنفيذ الحالي يرمي [UnsupportedOperationException] عمدًا.
     */
    suspend fun startTalkWithExternalAudio(deviceId: String, pcmChunkProvider: suspend () -> ByteArray?): Result<Unit>

    fun stopTalk(deviceId: String)
}
