package com.esa.imouaudiocontroller.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.esa.imouaudiocontroller.R
import com.esa.imouaudiocontroller.data.model.ExternalAudioInjectionCapability
import com.esa.imouaudiocontroller.data.model.OnlineStatus
import com.esa.imouaudiocontroller.data.model.SdkStatusSnapshot
import com.esa.imouaudiocontroller.data.model.TransmissionState

@Composable
fun SdkStatusScreen(status: SdkStatusSnapshot) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(stringResource(R.string.sdk_status_title), style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(16.dp))

        StatusRow(
            label = "Imou SDK",
            value = if (status.sdkConnected) {
                stringResource(R.string.status_connected)
            } else {
                stringResource(R.string.status_not_connected)
            }
        )
        StatusRow(
            label = "Camera",
            value = when (status.cameraOnline) {
                OnlineStatus.ONLINE -> stringResource(R.string.camera_status_online)
                OnlineStatus.OFFLINE -> stringResource(R.string.camera_status_offline)
                OnlineStatus.UNKNOWN -> stringResource(R.string.camera_status_unknown)
            }
        )
        StatusRow(
            label = "Talk capability",
            value = when (status.talkCapability) {
                ExternalAudioInjectionCapability.SUPPORTED -> stringResource(R.string.status_supported)
                ExternalAudioInjectionCapability.NOT_SUPPORTED -> stringResource(R.string.status_not_supported)
                ExternalAudioInjectionCapability.UNVERIFIED -> stringResource(R.string.status_unverified)
            }
        )
        StatusRow(
            label = "Audio file",
            value = if (status.audioFileReady) {
                stringResource(R.string.status_ready)
            } else {
                stringResource(R.string.status_error)
            }
        )
        StatusRow(
            label = "Audio transmission",
            value = when (status.transmissionState) {
                TransmissionState.READY -> stringResource(R.string.status_ready)
                TransmissionState.RUNNING -> stringResource(R.string.status_running)
                TransmissionState.ERROR -> stringResource(R.string.status_error)
                TransmissionState.NOT_APPLICABLE -> stringResource(R.string.status_unverified)
            }
        )
    }
}

@Composable
private fun StatusRow(label: String, value: String) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyLarge)
        Text(value, style = MaterialTheme.typography.bodyLarge)
    }
}
