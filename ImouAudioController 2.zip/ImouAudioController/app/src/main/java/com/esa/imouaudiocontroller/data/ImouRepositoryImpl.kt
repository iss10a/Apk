package com.esa.imouaudiocontroller.data

import com.esa.imouaudiocontroller.data.model.CameraInfo
import com.esa.imouaudiocontroller.data.model.ExternalAudioInjectionCapability
import com.esa.imouaudiocontroller.data.model.LoginState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * التنفيذ الحقيقي الذي سيغلّف Imou OpenSDK الرسمي (LCOpenSDK.aar).
 *
 * الوضع الحالي: هيكل فقط. لا توجد هنا أي استدعاءات SDK لأننا لم نستلم
 * بعد ملف .aar والتوثيق الرسمي لفحصه (كما هو متفق عليه في خطة العمل).
 *
 * كل دالة هنا:
 *  - إما ترمي NotImplementedError بوضوح ("لم يُدمج SDK بعد")
 *  - أو تعيد Result.failure بسبب واضح
 * ولا تدّعي أبدًا نجاحًا وهميًا.
 */
class ImouRepositoryImpl : ImouRepository {

    private val _loginState = MutableStateFlow<LoginState>(LoginState.NotConnected)
    override val loginState: StateFlow<LoginState> = _loginState.asStateFlow()

    override suspend fun login(username: String, password: String): Result<Unit> {
        // TODO(SDK-PENDING): استبدال هذا باستدعاء دخول Imou الرسمي بعد فحص LCOpenSDK.aar.
        _loginState.value = LoginState.Error("Imou SDK غير مدمج بعد — بانتظار فحص LCOpenSDK.aar")
        return Result.failure(
            NotImplementedError("Imou login غير منفَّذ بعد. لم يُدمَج SDK الرسمي في هذا الهيكل.")
        )
    }

    override fun logout() {
        _loginState.value = LoginState.NotConnected
    }

    override suspend fun fetchCameras(): Result<List<CameraInfo>> {
        return Result.failure(
            NotImplementedError("جلب قائمة الكاميرات يتطلب Imou SDK رسمي — غير مدمج بعد.")
        )
    }

    override suspend fun startLivePreview(deviceId: String): Result<Unit> {
        return Result.failure(
            NotImplementedError("المعاينة المباشرة تتطلب Imou SDK رسمي — غير مدمج بعد.")
        )
    }

    override fun stopLivePreview(deviceId: String) {
        // لا شيء بعد — لا يوجد اتصال فعلي لإيقافه.
    }

    override suspend fun checkExternalAudioInjectionCapability(
        deviceId: String
    ): ExternalAudioInjectionCapability {
        // هذه هي أهم دالة في المشروع بأكمله.
        // تبقى UNVERIFIED دائمًا حتى نفحص LCOpenSDK_Talk / LCOpenSDK_ParamTalk فعليًا
        // ونؤكد وجود (أو غياب) أي دالة لحقن PCM خارجي بدل الميكروفون.
        return ExternalAudioInjectionCapability.UNVERIFIED
    }

    override suspend fun startTalkWithExternalAudio(
        deviceId: String,
        pcmChunkProvider: suspend () -> ByteArray?
    ): Result<Unit> {
        return Result.failure(
            UnsupportedOperationException(
                "غير مسموح بتشغيل هذه الميزة قبل تأكيد دعم SDK لإدخال PCM خارجي. " +
                    "استدعِ checkExternalAudioInjectionCapability أولًا."
            )
        )
    }

    override fun stopTalk(deviceId: String) {
        // لا شيء بعد.
    }
}
