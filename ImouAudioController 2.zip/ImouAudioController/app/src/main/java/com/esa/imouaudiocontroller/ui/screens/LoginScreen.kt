package com.esa.imouaudiocontroller.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.res.stringResource
import com.esa.imouaudiocontroller.R
import com.esa.imouaudiocontroller.data.model.LoginState

@Composable
fun LoginScreen(
    loginState: LoginState,
    onLoginClick: (String, String) -> Unit
) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = stringResource(R.string.login_title),
            style = MaterialTheme.typography.headlineMedium
        )
        Spacer(Modifier.height(24.dp))

        OutlinedTextField(
            value = username,
            onValueChange = { username = it },
            label = { Text("Imou Username") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Imou Password") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(16.dp))

        Button(
            onClick = { onLoginClick(username, password) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(stringResource(R.string.login_button))
        }

        Spacer(Modifier.height(16.dp))

        when (loginState) {
            is LoginState.Error -> Text(
                text = loginState.message,
                color = MaterialTheme.colorScheme.error
            )
            is LoginState.Connecting -> CircularProgressIndicator()
            is LoginState.Connected -> Text("متصل: ${loginState.accountLabel}")
            LoginState.NotConnected -> Text(
                text = stringResource(R.string.login_pending),
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
