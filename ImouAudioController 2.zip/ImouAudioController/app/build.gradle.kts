import java.util.Properties
import java.io.FileInputStream

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// قراءة بيانات اعتماد Imou من local.properties (ملف محلي غير مرفوع لـ GitHub).
// إذا لم يوجد الملف أو المفاتيح، تبقى القيم فارغة ولا يتعطل البناء.
val localProperties = Properties().apply {
    val localFile = rootProject.file("local.properties")
    if (localFile.exists()) {
        load(FileInputStream(localFile))
    }
}

android {
    namespace = "com.esa.imouaudiocontroller"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.esa.imouaudiocontroller"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0-skeleton"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // تُقرأ من local.properties محليًا، أو من متغيرات بيئة Codemagic في CI.
        // لا تُكتب هذه القيم أبدًا مباشرة هنا.
        buildConfigField(
            "String",
            "IMOU_APP_ID",
            "\"${localProperties.getProperty("IMOU_APP_ID") ?: System.getenv("IMOU_APP_ID") ?: ""}\""
        )
        buildConfigField(
            "String",
            "IMOU_APP_SECRET",
            "\"${localProperties.getProperty("IMOU_APP_SECRET") ?: System.getenv("IMOU_APP_SECRET") ?: ""}\""
        )
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isDebuggable = true
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    // Compose BOM يضبط توافق إصدارات مكتبات Compose مع بعضها
    val composeBom = platform("androidx.compose:compose-bom:2024.06.00")
    implementation(composeBom)

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.3")
    implementation("androidx.activity:activity-compose:1.9.0")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.navigation:navigation-compose:2.7.7")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // مكان Imou OpenSDK الرسمي لاحقًا — لا يُضاف أي شيء هنا الآن:
    // implementation(files("libs/LCOpenSDK.aar"))
    // أو عبر مستودع Maven رسمي إذا أكّد التوثيق وجوده.

    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")

    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
    androidTestImplementation(composeBom)
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")
}
