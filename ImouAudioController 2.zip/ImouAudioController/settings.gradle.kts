pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // إذا تطلّب Imou OpenSDK مستودع Maven خاص، أضفه هنا لاحقًا بعد تأكيد ذلك من التوثيق الرسمي.
        // مثال محتمل (غير مؤكد بعد): maven("https://repo.imou.com/...")
    }
}

rootProject.name = "ImouAudioController"
include(":app")
